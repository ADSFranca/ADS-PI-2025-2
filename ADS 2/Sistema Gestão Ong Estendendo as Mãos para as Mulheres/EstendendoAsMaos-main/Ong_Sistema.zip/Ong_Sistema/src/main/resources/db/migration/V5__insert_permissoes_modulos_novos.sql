-- =============================================
-- Migration V5: Permissões dos Novos Módulos
-- =============================================

-- Inserir novas permissões
INSERT INTO permissoes (codigo_permissao, descricao) VALUES
('PROFISSIONAL_LEITURA', 'Visualizar profissionais'),
('PROFISSIONAL_ESCRITA', 'Criar/Editar profissionais'),
('PROFISSIONAL_EXCLUSAO', 'Excluir profissionais'),
('ATENDIMENTO_LEITURA', 'Visualizar atendimentos'),
('ATENDIMENTO_ESCRITA', 'Criar/Editar atendimentos'),
('ATENDIMENTO_EXCLUSAO', 'Excluir atendimentos'),
('VOLUNTARIO_LEITURA', 'Visualizar voluntários'),
('VOLUNTARIO_ESCRITA', 'Gerenciar voluntários'),
('CAMPANHA_LEITURA', 'Visualizar campanhas'),
('CAMPANHA_ESCRITA', 'Criar/Editar campanhas');

-- Associar novas permissões ao perfil ADMINISTRADOR
INSERT INTO perfil_permissoes (id_perfil, id_permissao)
SELECT 1, id FROM permissoes WHERE codigo_permissao IN (
    'PROFISSIONAL_LEITURA', 'PROFISSIONAL_ESCRITA', 'PROFISSIONAL_EXCLUSAO',
    'ATENDIMENTO_LEITURA', 'ATENDIMENTO_ESCRITA', 'ATENDIMENTO_EXCLUSAO',
    'VOLUNTARIO_LEITURA', 'VOLUNTARIO_ESCRITA',
    'CAMPANHA_LEITURA', 'CAMPANHA_ESCRITA'
);

-- Associar permissões de leitura ao perfil COORDENADOR
INSERT INTO perfil_permissoes (id_perfil, id_permissao)
SELECT 2, id FROM permissoes WHERE codigo_permissao IN (
    'PROFISSIONAL_LEITURA', 'ATENDIMENTO_LEITURA', 'ATENDIMENTO_ESCRITA',
    'VOLUNTARIO_LEITURA', 'CAMPANHA_LEITURA'
);
