-- =============================================
-- Migration V7: Chamados e Auditoria
-- =============================================

-- Tabela de Chamados (Help Desk)
CREATE TABLE chamados (
    id BIGSERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    prioridade VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ABERTO',
    criado_por BIGINT,
    atribuido_para BIGINT,
    resolucao TEXT,
    data_abertura TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP,
    data_fechamento TIMESTAMP,
    FOREIGN KEY (criado_por) REFERENCES usuarios(id),
    FOREIGN KEY (atribuido_para) REFERENCES usuarios(id)
);

-- Tabela de Logs de Auditoria
CREATE TABLE logs_auditoria (
    id BIGSERIAL PRIMARY KEY,
    id_usuario BIGINT,
    acao VARCHAR(50) NOT NULL,
    entidade VARCHAR(100) NOT NULL,
    id_entidade BIGINT,
    detalhes TEXT,
    ip_origem VARCHAR(50),
    data_hora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);

-- Índices
CREATE INDEX idx_chamados_status ON chamados(status);
CREATE INDEX idx_chamados_criado_por ON chamados(criado_por);
CREATE INDEX idx_chamados_atribuido ON chamados(atribuido_para);
CREATE INDEX idx_auditoria_usuario ON logs_auditoria(id_usuario);
CREATE INDEX idx_auditoria_entidade ON logs_auditoria(entidade, id_entidade);
CREATE INDEX idx_auditoria_data ON logs_auditoria(data_hora);

-- Inserir novas permissões
INSERT INTO permissoes (codigo_permissao, descricao) VALUES
('CHAMADO_GESTAO', 'Gerenciar chamados'),
('RELATORIO_LEITURA', 'Visualizar relatórios');

-- Associar ao perfil ADMINISTRADOR
INSERT INTO perfil_permissoes (id_perfil, id_permissao)
SELECT 1, id FROM permissoes WHERE codigo_permissao IN ('CHAMADO_GESTAO', 'RELATORIO_LEITURA');

-- Associar RELATORIO_LEITURA ao COORDENADOR
INSERT INTO perfil_permissoes (id_perfil, id_permissao)
SELECT 2, id FROM permissoes WHERE codigo_permissao = 'RELATORIO_LEITURA';
