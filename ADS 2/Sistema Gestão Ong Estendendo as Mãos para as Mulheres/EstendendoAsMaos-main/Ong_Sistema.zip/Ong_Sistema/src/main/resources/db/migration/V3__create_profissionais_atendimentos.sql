-- =============================================
-- Migration V3: Profissionais e Atendimentos
-- =============================================

-- Tabela de Profissionais
CREATE TABLE profissionais (
    id BIGSERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    tipo VARCHAR(50) NOT NULL,
    numero_registro VARCHAR(50),
    especialidade VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'ATIVO',
    tipo_vinculo VARCHAR(30) NOT NULL,
    observacoes TEXT,
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP
);

-- Tabela de Atendimentos
CREATE TABLE atendimentos (
    id BIGSERIAL PRIMARY KEY,
    id_beneficiaria BIGINT NOT NULL,
    id_profissional BIGINT NOT NULL,
    data_hora_atendimento TIMESTAMP NOT NULL,
    tipo_atendimento VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'AGENDADO',
    relatorio_criptografado TEXT,
    proxima_sessao TIMESTAMP,
    observacoes TEXT,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_beneficiaria) REFERENCES beneficiarias(id) ON DELETE RESTRICT,
    FOREIGN KEY (id_profissional) REFERENCES profissionais(id) ON DELETE RESTRICT
);

-- Índices
CREATE INDEX idx_profissionais_status ON profissionais(status);
CREATE INDEX idx_profissionais_tipo ON profissionais(tipo);
CREATE INDEX idx_atendimentos_beneficiaria ON atendimentos(id_beneficiaria);
CREATE INDEX idx_atendimentos_profissional ON atendimentos(id_profissional);
CREATE INDEX idx_atendimentos_data ON atendimentos(data_hora_atendimento);
CREATE INDEX idx_atendimentos_status ON atendimentos(status);

-- Dados de exemplo
INSERT INTO profissionais (nome_completo, email, telefone, tipo, numero_registro, especialidade, tipo_vinculo) VALUES
('Dra. Maria Silva', 'maria.silva@ong.org', '11999998888', 'PSICOLOGO', 'CRP 06/12345', 'Terapia Cognitivo-Comportamental', 'CLT'),
('Dr. João Santos', 'joao.santos@ong.org', '11999997777', 'ADVOGADO', 'OAB/SP 123456', 'Direito da Família', 'PRESTADOR_SERVICO'),
('Carla Oliveira', 'carla.oliveira@ong.org', '11999996666', 'ASSISTENTE_SOCIAL', 'CRESS 12345', 'Assistência Social', 'VOLUNTARIO');
