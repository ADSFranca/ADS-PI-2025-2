-- =============================================
-- Migration V4: Voluntários e Campanhas
-- =============================================

-- Tabela de Voluntários
CREATE TABLE voluntarios (
    id BIGSERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    area_interesse VARCHAR(255),
    disponibilidade VARCHAR(255),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDENTE',
    horas_trabalhadas INTEGER DEFAULT 0,
    observacoes TEXT,
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_aprovacao TIMESTAMP,
    aprovado_por BIGINT,
    FOREIGN KEY (aprovado_por) REFERENCES usuarios(id)
);

-- Tabela de Campanhas
CREATE TABLE campanhas (
    id BIGSERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    meta_financeira DECIMAL(10,2),
    valor_arrecadado DECIMAL(10,2) DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'PLANEJAMENTO',
    imagem_url VARCHAR(500),
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    criado_por BIGINT,
    FOREIGN KEY (criado_por) REFERENCES usuarios(id)
);

-- Índices
CREATE INDEX idx_voluntarios_status ON voluntarios(status);
CREATE INDEX idx_voluntarios_email ON voluntarios(email);
CREATE INDEX idx_campanhas_status ON campanhas(status);
CREATE INDEX idx_campanhas_datas ON campanhas(data_inicio, data_fim);
