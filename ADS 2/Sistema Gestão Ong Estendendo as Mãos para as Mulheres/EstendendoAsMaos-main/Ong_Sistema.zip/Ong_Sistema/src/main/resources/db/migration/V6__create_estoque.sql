-- =============================================
-- Migration V6: Sistema de Estoque
-- =============================================

CREATE TABLE itens_estoque (
    id BIGSERIAL PRIMARY KEY,
    codigo_barras VARCHAR(50) UNIQUE,
    nome_item VARCHAR(255) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(50) NOT NULL,
    quantidade_atual INTEGER NOT NULL DEFAULT 0,
    quantidade_minima INTEGER NOT NULL DEFAULT 10,
    data_validade DATE,
    local_armazenamento VARCHAR(100),
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP,
    cadastrado_por BIGINT,
    FOREIGN KEY (cadastrado_por) REFERENCES usuarios(id)
);

CREATE INDEX idx_estoque_codigo_barras ON itens_estoque(codigo_barras);
CREATE INDEX idx_estoque_categoria ON itens_estoque(categoria);
CREATE INDEX idx_estoque_quantidade ON itens_estoque(quantidade_atual);

-- Inserir permissões de estoque
INSERT INTO permissoes (codigo_permissao, descricao) VALUES
('ESTOQUE_LEITURA', 'Visualizar estoque'),
('ESTOQUE_ESCRITA', 'Gerenciar estoque');

-- Associar ao perfil ADMINISTRADOR
INSERT INTO perfil_permissoes (id_perfil, id_permissao)
SELECT 1, id FROM permissoes WHERE codigo_permissao IN ('ESTOQUE_LEITURA', 'ESTOQUE_ESCRITA');

-- Dados de exemplo
INSERT INTO itens_estoque (nome_item, categoria, quantidade_atual, quantidade_minima, local_armazenamento, codigo_barras) VALUES
('Cesta Básica Completa', 'ALIMENTO', 50, 20, 'Almoxarifado A', '7891234567890'),
('Kit Higiene Pessoal', 'HIGIENE', 30, 15, 'Almoxarifado A', '7891234567891'),
('Roupas Femininas (P)', 'VESTUARIO', 25, 10, 'Almoxarifado B', '7891234567892'),
('Material Escolar Básico', 'MATERIAL_ESCOLAR', 40, 20, 'Almoxarifado C', '7891234567893');
