-- =============================================
-- Sistema de Gestão para ONG
-- Migration V1: Criação das tabelas iniciais
-- =============================================

-- Tabela de Permissões
CREATE TABLE permissoes (
    id BIGSERIAL PRIMARY KEY,
    codigo_permissao VARCHAR(100) UNIQUE NOT NULL,
    descricao VARCHAR(255)
);

-- Tabela de Perfis de Acesso
CREATE TABLE perfis_acesso (
    id BIGSERIAL PRIMARY KEY,
    nome_perfil VARCHAR(100) UNIQUE NOT NULL,
    descricao TEXT,
    nivel_acesso INTEGER NOT NULL
);

-- Tabela de relação Perfil-Permissões (muitos para muitos)
CREATE TABLE perfil_permissoes (
    id_perfil BIGINT NOT NULL,
    id_permissao BIGINT NOT NULL,
    PRIMARY KEY (id_perfil, id_permissao),
    FOREIGN KEY (id_perfil) REFERENCES perfis_acesso(id) ON DELETE CASCADE,
    FOREIGN KEY (id_permissao) REFERENCES permissoes(id) ON DELETE CASCADE
);

-- Tabela de Usuários
CREATE TABLE usuarios (
    id BIGSERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    id_perfil BIGINT,
    status VARCHAR(20) NOT NULL DEFAULT 'ATIVO',
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP,
    FOREIGN KEY (id_perfil) REFERENCES perfis_acesso(id)
);

-- Tabela de Beneficiárias
CREATE TABLE beneficiarias (
    id BIGSERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    cpf_criptografado VARCHAR(255) UNIQUE NOT NULL,
    data_nascimento DATE,
    endereco TEXT,
    telefone VARCHAR(20),
    email VARCHAR(255),
    status VARCHAR(20) NOT NULL DEFAULT 'ATIVA',
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Doações
CREATE TABLE doacoes (
    id BIGSERIAL PRIMARY KEY,
    valor_doacao DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDENTE',
    codigo_transacao VARCHAR(100),
    nome_doador VARCHAR(255),
    email_doador VARCHAR(255),
    data_doacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_perfil ON usuarios(id_perfil);
CREATE INDEX idx_beneficiarias_cpf ON beneficiarias(cpf_criptografado);
CREATE INDEX idx_doacoes_status ON doacoes(status);
