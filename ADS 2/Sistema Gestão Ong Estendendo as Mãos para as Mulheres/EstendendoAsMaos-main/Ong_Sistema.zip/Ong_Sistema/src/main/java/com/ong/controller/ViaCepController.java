package com.ong.controller;

import com.ong.dto.EnderecoViaCepDTO;
import com.ong.service.ViaCepService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/public/cep")
@RequiredArgsConstructor
public class ViaCepController {

    private final ViaCepService viaCepService;

    @GetMapping("/{cep}")
    public ResponseEntity<EnderecoViaCepDTO> buscarCep(@PathVariable String cep) {
        EnderecoViaCepDTO endereco = viaCepService.buscarEnderecoPorCep(cep);
        return ResponseEntity.ok(endereco);
    }
}
