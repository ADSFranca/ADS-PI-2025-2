package com.ong.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ProfissionalDTO {
    private Long id;

    @NotBlank(message = "Nome completo é obrigatório")
    private String nomeCompleto;

    @NotBlank @Email
    private String email;

    private String telefone;

    @NotBlank
    private String tipo;

    private String numeroRegistro;
    private String especialidade;
    private String status;

    @NotBlank
    private String tipoVinculo;

    private String observacoes;
}
