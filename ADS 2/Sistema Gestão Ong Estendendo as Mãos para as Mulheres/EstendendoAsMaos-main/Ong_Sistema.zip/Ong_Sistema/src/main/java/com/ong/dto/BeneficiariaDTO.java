package com.ong.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class BeneficiariaDTO {

    private Long id;

    @NotBlank
    private String nomeCompleto;

    @NotBlank
    private String cpf;

    private LocalDate dataNascimento;

    private String endereco;

    private String telefone;

    private String email;
}
