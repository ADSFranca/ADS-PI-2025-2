package com.ong.service;

import com.ong.dto.BeneficiariaDTO;
import com.ong.model.Beneficiaria;
import com.ong.repository.BeneficiariaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BeneficiariaService {

    private final BeneficiariaRepository repository;

    @Transactional(readOnly = true)
    public List<BeneficiariaDTO> listarTodas() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BeneficiariaDTO buscarPorId(Long id) {
        Beneficiaria beneficiaria = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Beneficiária não encontrada"));
        return toDTO(beneficiaria);
    }

    @Transactional
    public BeneficiariaDTO criar(BeneficiariaDTO dto) {
        Beneficiaria beneficiaria = Beneficiaria.builder()
            .nomeCompleto(dto.getNomeCompleto())
            .cpfCriptografado(dto.getCpf()) // TODO: criptografar
            .dataNascimento(dto.getDataNascimento())
            .endereco(dto.getEndereco())
            .telefone(dto.getTelefone())
            .email(dto.getEmail())
            .build();

        beneficiaria = repository.save(beneficiaria);
        return toDTO(beneficiaria);
    }

    private BeneficiariaDTO toDTO(Beneficiaria b) {
        BeneficiariaDTO dto = new BeneficiariaDTO();
        dto.setId(b.getId());
        dto.setNomeCompleto(b.getNomeCompleto());
        dto.setDataNascimento(b.getDataNascimento());
        dto.setEndereco(b.getEndereco());
        dto.setTelefone(b.getTelefone());
        dto.setEmail(b.getEmail());
        return dto;
    }
}
