package com.ong.repository;

import com.ong.model.Doacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;

@Repository
public interface DoacaoRepository extends JpaRepository<Doacao, Long> {
    @Query("SELECT SUM(d.valorDoacao) FROM Doacao d WHERE d.status = 'CONFIRMADA'")
    BigDecimal somarTotalDoacoes();
}
