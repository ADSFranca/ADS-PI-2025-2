package com.ong.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class CampanhaDTO {
    private Long id;

    @NotBlank
    private String titulo;

    private String descricao;

    @NotNull
    private LocalDate dataInicio;

    @NotNull
    private LocalDate dataFim;

    private BigDecimal metaFinanceira;
    private BigDecimal valorArrecadado;
    private String status;
    private String imagemUrl;
    private Double percentualAtingido;
}
