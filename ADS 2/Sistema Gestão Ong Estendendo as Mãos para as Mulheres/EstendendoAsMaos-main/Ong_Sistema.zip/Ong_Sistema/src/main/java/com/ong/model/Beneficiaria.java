package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "beneficiarias")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Beneficiaria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nomeCompleto;

    @Column(unique = true, nullable = false)
    private String cpfCriptografado;

    private LocalDate dataNascimento;

    @Column(columnDefinition = "TEXT")
    private String endereco;

    private String telefone;

    private String email;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Status status = Status.ATIVA;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCadastro;

    public enum Status {
        ATIVA, INATIVA, AGUARDANDO_DOC
    }

    // Métodos auxiliares para compatibilizar com o service (getCpf / setCpf)

    public String getCpf() {
        return cpfCriptografado;
    }

    public void setCpf(String cpf) {
        this.cpfCriptografado = cpf;
    }
}
