package com.ong.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ItemEstoqueDTO {
    private Long id;
    private String codigoBarras;

    @NotBlank
    private String nomeItem;

    private String descricao;

    @NotBlank
    private String categoria;

    @NotNull @Positive
    private Integer quantidadeAtual;

    @NotNull @Positive
    private Integer quantidadeMinima;

    private LocalDate dataValidade;
    private String localArmazenamento;
    private Boolean estoqueBaixo;
}
