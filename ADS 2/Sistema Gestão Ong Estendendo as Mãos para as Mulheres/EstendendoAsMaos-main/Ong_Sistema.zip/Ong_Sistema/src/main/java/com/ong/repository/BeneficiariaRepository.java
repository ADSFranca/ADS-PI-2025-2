package com.ong.repository;

import com.ong.model.Beneficiaria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BeneficiariaRepository extends JpaRepository<Beneficiaria, Long> {
}
