package com.ong.controller;

import com.ong.dto.CampanhaDTO;
import com.ong.service.CampanhaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/campanhas")
@RequiredArgsConstructor
public class CampanhaController {

    private final CampanhaService service;

    @GetMapping
    public ResponseEntity<List<CampanhaDTO>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }

    @GetMapping("/ativas")
    public ResponseEntity<List<CampanhaDTO>> listarAtivas() {
        return ResponseEntity.ok(service.listarAtivas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CampanhaDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('CAMPANHA_ESCRITA', 'ADMIN')")
    public ResponseEntity<CampanhaDTO> criar(@Valid @RequestBody CampanhaDTO dto) {
        return ResponseEntity.ok(service.criar(dto));
    }

    @PutMapping("/{id}/ativar")
    @PreAuthorize("hasAnyAuthority('CAMPANHA_ESCRITA', 'ADMIN')")
    public ResponseEntity<CampanhaDTO> ativar(@PathVariable Long id) {
        return ResponseEntity.ok(service.ativar(id));
    }

    @PutMapping("/{id}/encerrar")
    @PreAuthorize("hasAnyAuthority('CAMPANHA_ESCRITA', 'ADMIN')")
    public ResponseEntity<CampanhaDTO> encerrar(@PathVariable Long id) {
        return ResponseEntity.ok(service.encerrar(id));
    }
}
