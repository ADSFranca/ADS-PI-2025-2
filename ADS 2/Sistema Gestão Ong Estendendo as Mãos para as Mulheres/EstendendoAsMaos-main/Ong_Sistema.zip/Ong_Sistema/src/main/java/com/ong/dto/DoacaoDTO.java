package com.ong.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class DoacaoDTO {
    private Long id;
    @NotNull @Positive
    private BigDecimal valorDoacao;
    private String nomeDoador;
    private String emailDoador;
    private String status;
}
