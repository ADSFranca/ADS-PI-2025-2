package com.ong.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ChamadoDTO {
    private Long id;

    @NotBlank
    private String titulo;

    @NotBlank
    private String descricao;

    @NotNull
    private String categoria;

    @NotNull
    private String prioridade;

    private String status;
    private Long idCriadoPor;
    private String nomeCriadoPor;
    private Long idAtribuidoPara;
    private String nomeAtribuidoPara;
    private String resolucao;
    private LocalDateTime dataAbertura;
    private LocalDateTime dataFechamento;
}
