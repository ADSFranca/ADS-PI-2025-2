package com.ong.service;

import com.ong.dto.DoacaoDTO;
import com.ong.model.Doacao;
import com.ong.repository.DoacaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DoacaoService {

    private final DoacaoRepository repository;

    @Transactional(readOnly = true)
    public List<DoacaoDTO> listarTodas() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional
    public DoacaoDTO criar(DoacaoDTO dto) {
        Doacao doacao = Doacao.builder()
            .valorDoacao(dto.getValorDoacao())
            .nomeDoador(dto.getNomeDoador())
            .emailDoador(dto.getEmailDoador())
            .build();

        doacao = repository.save(doacao);
        return toDTO(doacao);
    }

    @Transactional(readOnly = true)
    public BigDecimal calcularTotalDoacoes() {
        BigDecimal total = repository.somarTotalDoacoes();
        return total != null ? total : BigDecimal.ZERO;
    }

    private DoacaoDTO toDTO(Doacao d) {
        DoacaoDTO dto = new DoacaoDTO();
        dto.setId(d.getId());
        dto.setValorDoacao(d.getValorDoacao());
        dto.setNomeDoador(d.getNomeDoador());
        dto.setEmailDoador(d.getEmailDoador());
        dto.setStatus(d.getStatus().name());
        return dto;
    }
}
