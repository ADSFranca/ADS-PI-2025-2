package com.ong.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AtendimentoDTO {
    private Long id;

    @NotNull
    private Long idBeneficiaria;

    @NotNull
    private Long idProfissional;

    @NotNull
    private LocalDateTime dataHoraAtendimento;

    @NotNull
    private String tipoAtendimento;

    private String status;
    private String relatorio;
    private LocalDateTime proximaSessao;
    private String observacoes;

    // Campos extras para exibição
    private String nomeBeneficiaria;
    private String nomeProfissional;
}
