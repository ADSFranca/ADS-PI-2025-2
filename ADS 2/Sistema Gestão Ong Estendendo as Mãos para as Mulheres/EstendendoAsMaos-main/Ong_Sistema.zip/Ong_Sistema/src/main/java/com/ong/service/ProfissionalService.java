package com.ong.service;

import com.ong.dto.ProfissionalDTO;
import com.ong.model.Profissional;
import com.ong.repository.ProfissionalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProfissionalService {

    private final ProfissionalRepository repository;

    @Transactional(readOnly = true)
    public List<ProfissionalDTO> listarTodos() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProfissionalDTO> listarAtivos() {
        return repository.findByStatus(Profissional.StatusProfissional.ATIVO).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProfissionalDTO> listarPorTipo(String tipo) {
        Profissional.TipoProfissional tipoProfissional = Profissional.TipoProfissional.valueOf(tipo.toUpperCase());
        return repository.findByTipo(tipoProfissional).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProfissionalDTO buscarPorId(Long id) {
        Profissional profissional = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Profissional não encontrado"));
        return toDTO(profissional);
    }

    @Transactional
    public ProfissionalDTO criar(ProfissionalDTO dto) {
        Profissional profissional = Profissional.builder()
            .nomeCompleto(dto.getNomeCompleto())
            .email(dto.getEmail())
            .telefone(dto.getTelefone())
            .tipo(Profissional.TipoProfissional.valueOf(dto.getTipo().toUpperCase()))
            .numeroRegistro(dto.getNumeroRegistro())
            .especialidade(dto.getEspecialidade())
            .tipoVinculo(Profissional.TipoVinculo.valueOf(dto.getTipoVinculo().toUpperCase()))
            .observacoes(dto.getObservacoes())
            .build();

        profissional = repository.save(profissional);
        return toDTO(profissional);
    }

    @Transactional
    public ProfissionalDTO atualizar(Long id, ProfissionalDTO dto) {
        Profissional profissional = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Profissional não encontrado"));

        profissional.setNomeCompleto(dto.getNomeCompleto());
        profissional.setEmail(dto.getEmail());
        profissional.setTelefone(dto.getTelefone());
        profissional.setEspecialidade(dto.getEspecialidade());
        profissional.setObservacoes(dto.getObservacoes());

        profissional = repository.save(profissional);
        return toDTO(profissional);
    }

    @Transactional
    public void inativar(Long id) {
        Profissional profissional = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Profissional não encontrado"));
        profissional.setStatus(Profissional.StatusProfissional.INATIVO);
        repository.save(profissional);
    }

    private ProfissionalDTO toDTO(Profissional p) {
        ProfissionalDTO dto = new ProfissionalDTO();
        dto.setId(p.getId());
        dto.setNomeCompleto(p.getNomeCompleto());
        dto.setEmail(p.getEmail());
        dto.setTelefone(p.getTelefone());
        dto.setTipo(p.getTipo().name());
        dto.setNumeroRegistro(p.getNumeroRegistro());
        dto.setEspecialidade(p.getEspecialidade());
        dto.setStatus(p.getStatus().name());
        dto.setTipoVinculo(p.getTipoVinculo().name());
        dto.setObservacoes(p.getObservacoes());
        return dto;
    }
}
