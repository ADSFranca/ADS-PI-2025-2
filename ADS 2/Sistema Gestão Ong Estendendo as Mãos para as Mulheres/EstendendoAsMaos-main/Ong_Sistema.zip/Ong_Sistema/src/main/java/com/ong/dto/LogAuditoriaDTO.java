package com.ong.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class LogAuditoriaDTO {
    private Long id;
    private Long idUsuario;
    private String nomeUsuario;
    private String acao;
    private String entidade;
    private Long idEntidade;
    private String detalhes;
    private String ipOrigem;
    private LocalDateTime dataHora;
}
