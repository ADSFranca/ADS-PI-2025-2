package com.ong.controller;

import com.ong.dto.ItemEstoqueDTO;
import com.ong.service.ItemEstoqueService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/estoque")
@RequiredArgsConstructor
public class ItemEstoqueController {

    private final ItemEstoqueService service;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('ESTOQUE_LEITURA', 'ADMIN')")
    public ResponseEntity<List<ItemEstoqueDTO>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/baixo")
    @PreAuthorize("hasAnyAuthority('ESTOQUE_LEITURA', 'ADMIN')")
    public ResponseEntity<List<ItemEstoqueDTO>> listarEstoqueBaixo() {
        return ResponseEntity.ok(service.listarEstoqueBaixo());
    }

    @GetMapping("/codigo-barras/{codigo}")
    @PreAuthorize("hasAnyAuthority('ESTOQUE_LEITURA', 'ADMIN')")
    public ResponseEntity<ItemEstoqueDTO> buscarPorCodigoBarras(@PathVariable String codigo) {
        return ResponseEntity.ok(service.buscarPorCodigoBarras(codigo));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ESTOQUE_ESCRITA', 'ADMIN')")
    public ResponseEntity<ItemEstoqueDTO> criar(@Valid @RequestBody ItemEstoqueDTO dto) {
        return ResponseEntity.ok(service.criar(dto));
    }

    @PutMapping("/{id}/adicionar")
    @PreAuthorize("hasAnyAuthority('ESTOQUE_ESCRITA', 'ADMIN')")
    public ResponseEntity<ItemEstoqueDTO> adicionarQuantidade(
            @PathVariable Long id, 
            @RequestParam Integer quantidade) {
        return ResponseEntity.ok(service.adicionarQuantidade(id, quantidade));
    }

    @PutMapping("/{id}/remover")
    @PreAuthorize("hasAnyAuthority('ESTOQUE_ESCRITA', 'ADMIN')")
    public ResponseEntity<ItemEstoqueDTO> removerQuantidade(
            @PathVariable Long id, 
            @RequestParam Integer quantidade) {
        return ResponseEntity.ok(service.removerQuantidade(id, quantidade));
    }
}
