package com.ong.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "permissoes")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Permissao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String codigoPermissao;

    private String descricao;
}
