package com.ong.controller;

import com.ong.dto.ChamadoDTO;
import com.ong.service.ChamadoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/chamados")
@RequiredArgsConstructor
public class ChamadoController {

    private final ChamadoService service;

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<ChamadoDTO>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/ativos")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<ChamadoDTO>> listarAtivos() {
        return ResponseEntity.ok(service.listarAtivos());
    }

    @GetMapping("/abertos/count")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Long> contarAbertos() {
        return ResponseEntity.ok(service.contarAbertos());
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ChamadoDTO> criar(
            @Valid @RequestBody ChamadoDTO dto,
            Authentication authentication) {
        // Pegar ID do usuário logado do token JWT
        Long idUsuario = 1L; // TODO: extrair do authentication
        return ResponseEntity.ok(service.criar(dto, idUsuario));
    }

    @PutMapping("/{id}/atribuir/{idUsuario}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'CHAMADO_GESTAO')")
    public ResponseEntity<ChamadoDTO> atribuir(
            @PathVariable Long id,
            @PathVariable Long idUsuario) {
        return ResponseEntity.ok(service.atribuir(id, idUsuario));
    }

    @PutMapping("/{id}/resolver")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ChamadoDTO> resolver(
            @PathVariable Long id,
            @RequestBody String resolucao) {
        return ResponseEntity.ok(service.resolver(id, resolucao));
    }

    @PutMapping("/{id}/fechar")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'CHAMADO_GESTAO')")
    public ResponseEntity<ChamadoDTO> fechar(@PathVariable Long id) {
        return ResponseEntity.ok(service.fechar(id));
    }
}
