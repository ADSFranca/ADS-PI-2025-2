package com.ong.controller;

import com.ong.dto.DoacaoDTO;
import com.ong.service.DoacaoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/doacoes")
@RequiredArgsConstructor
public class DoacaoController {

    private final DoacaoService service;

    @GetMapping
    public ResponseEntity<List<DoacaoDTO>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }

    @PostMapping("/public/iniciar")
    public ResponseEntity<DoacaoDTO> criar(@Valid @RequestBody DoacaoDTO dto) {
        return ResponseEntity.ok(service.criar(dto));
    }

    @GetMapping("/public/total")
    public ResponseEntity<BigDecimal> total() {
        return ResponseEntity.ok(service.calcularTotalDoacoes());
    }
}
