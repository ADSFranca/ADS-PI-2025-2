package com.ong.repository;

import com.ong.model.Atendimento;
import com.ong.model.Beneficiaria;
import com.ong.model.Profissional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AtendimentoRepository extends JpaRepository<Atendimento, Long> {
    List<Atendimento> findByBeneficiaria(Beneficiaria beneficiaria);
    List<Atendimento> findByProfissional(Profissional profissional);
    List<Atendimento> findByDataHoraAtendimentoBetween(LocalDateTime inicio, LocalDateTime fim);
    List<Atendimento> findByStatus(Atendimento.StatusAtendimento status);

    @Query("SELECT a FROM Atendimento a WHERE a.profissional.id = :profissionalId AND a.dataHoraAtendimento >= :dataInicio AND a.dataHoraAtendimento <= :dataFim")
    List<Atendimento> buscarAgendaDoProfissional(Long profissionalId, LocalDateTime dataInicio, LocalDateTime dataFim);
}
