package com.ong.service;

import com.ong.dto.VoluntarioDTO;
import com.ong.model.Voluntario;
import com.ong.repository.VoluntarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VoluntarioService {

    private final VoluntarioRepository repository;

    @Transactional(readOnly = true)
    public List<VoluntarioDTO> listarTodos() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VoluntarioDTO> listarPendentes() {
        return repository.findByStatus(Voluntario.StatusVoluntario.PENDENTE).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VoluntarioDTO> listarAtivos() {
        return repository.findByStatus(Voluntario.StatusVoluntario.ATIVO).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional
    public VoluntarioDTO candidatar(VoluntarioDTO dto) {
        Voluntario voluntario = Voluntario.builder()
            .nomeCompleto(dto.getNomeCompleto())
            .email(dto.getEmail())
            .telefone(dto.getTelefone())
            .areaInteresse(dto.getAreaInteresse())
            .disponibilidade(dto.getDisponibilidade())
            .observacoes(dto.getObservacoes())
            .build();

        voluntario = repository.save(voluntario);
        return toDTO(voluntario);
    }

    @Transactional
    public VoluntarioDTO aprovar(Long id) {
        Voluntario voluntario = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Voluntário não encontrado"));

        voluntario.setStatus(Voluntario.StatusVoluntario.ATIVO);
        voluntario.setDataAprovacao(LocalDateTime.now());

        voluntario = repository.save(voluntario);
        return toDTO(voluntario);
    }

    @Transactional
    public VoluntarioDTO rejeitar(Long id) {
        Voluntario voluntario = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Voluntário não encontrado"));

        voluntario.setStatus(Voluntario.StatusVoluntario.REJEITADO);
        voluntario = repository.save(voluntario);
        return toDTO(voluntario);
    }

    @Transactional
    public VoluntarioDTO registrarHoras(Long id, Integer horas) {
        Voluntario voluntario = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Voluntário não encontrado"));

        voluntario.setHorasTrabalhadas(voluntario.getHorasTrabalhadas() + horas);
        voluntario = repository.save(voluntario);
        return toDTO(voluntario);
    }

    private VoluntarioDTO toDTO(Voluntario v) {
        VoluntarioDTO dto = new VoluntarioDTO();
        dto.setId(v.getId());
        dto.setNomeCompleto(v.getNomeCompleto());
        dto.setEmail(v.getEmail());
        dto.setTelefone(v.getTelefone());
        dto.setAreaInteresse(v.getAreaInteresse());
        dto.setDisponibilidade(v.getDisponibilidade());
        dto.setStatus(v.getStatus().name());
        dto.setHorasTrabalhadas(v.getHorasTrabalhadas());
        dto.setObservacoes(v.getObservacoes());
        return dto;
    }
}
