package com.ong.service;

import com.ong.dto.ChamadoDTO;
import com.ong.model.Chamado;
import com.ong.model.Usuario;
import com.ong.repository.ChamadoRepository;
import com.ong.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ChamadoService {

    private final ChamadoRepository repository;
    private final UsuarioRepository usuarioRepository;

    @Transactional(readOnly = true)
    public List<ChamadoDTO> listarTodos() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ChamadoDTO> listarAtivos() {
        return repository.findChamadosAtivos().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Long contarAbertos() {
        return repository.contarChamadosAbertos();
    }

    @Transactional
    public ChamadoDTO criar(ChamadoDTO dto, Long idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        Chamado chamado = Chamado.builder()
            .titulo(dto.getTitulo())
            .descricao(dto.getDescricao())
            .categoria(Chamado.Categoria.valueOf(dto.getCategoria().toUpperCase()))
            .prioridade(Chamado.Prioridade.valueOf(dto.getPrioridade().toUpperCase()))
            .criadoPor(usuario)
            .build();

        chamado = repository.save(chamado);
        return toDTO(chamado);
    }

    @Transactional
    public ChamadoDTO atribuir(Long id, Long idUsuario) {
        Chamado chamado = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Chamado não encontrado"));

        Usuario usuario = usuarioRepository.findById(idUsuario)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        chamado.setAtribuidoPara(usuario);
        chamado.setStatus(Chamado.Status.EM_ANDAMENTO);

        chamado = repository.save(chamado);
        return toDTO(chamado);
    }

    @Transactional
    public ChamadoDTO resolver(Long id, String resolucao) {
        Chamado chamado = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Chamado não encontrado"));

        chamado.setResolucao(resolucao);
        chamado.setStatus(Chamado.Status.RESOLVIDO);
        chamado.setDataFechamento(LocalDateTime.now());

        chamado = repository.save(chamado);
        return toDTO(chamado);
    }

    @Transactional
    public ChamadoDTO fechar(Long id) {
        Chamado chamado = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Chamado não encontrado"));

        chamado.setStatus(Chamado.Status.FECHADO);
        if (chamado.getDataFechamento() == null) {
            chamado.setDataFechamento(LocalDateTime.now());
        }

        chamado = repository.save(chamado);
        return toDTO(chamado);
    }

    private ChamadoDTO toDTO(Chamado c) {
        ChamadoDTO dto = new ChamadoDTO();
        dto.setId(c.getId());
        dto.setTitulo(c.getTitulo());
        dto.setDescricao(c.getDescricao());
        dto.setCategoria(c.getCategoria().name());
        dto.setPrioridade(c.getPrioridade().name());
        dto.setStatus(c.getStatus().name());

        if (c.getCriadoPor() != null) {
            dto.setIdCriadoPor(c.getCriadoPor().getId());
            dto.setNomeCriadoPor(c.getCriadoPor().getNomeCompleto());
        }

        if (c.getAtribuidoPara() != null) {
            dto.setIdAtribuidoPara(c.getAtribuidoPara().getId());
            dto.setNomeAtribuidoPara(c.getAtribuidoPara().getNomeCompleto());
        }

        dto.setResolucao(c.getResolucao());
        dto.setDataAbertura(c.getDataAbertura());
        dto.setDataFechamento(c.getDataFechamento());

        return dto;
    }
}
