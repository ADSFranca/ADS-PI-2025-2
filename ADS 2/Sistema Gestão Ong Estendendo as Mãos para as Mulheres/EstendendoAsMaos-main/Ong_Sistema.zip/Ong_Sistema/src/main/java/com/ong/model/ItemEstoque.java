package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "itens_estoque")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class ItemEstoque {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, length = 50)
    private String codigoBarras;

    @Column(nullable = false)
    private String nomeItem;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CategoriaItem categoria;

    @Column(nullable = false)
    @Builder.Default
    private Integer quantidadeAtual = 0;

    @Column(nullable = false)
    @Builder.Default
    private Integer quantidadeMinima = 10;

    private LocalDate dataValidade;

    private String localArmazenamento;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCadastro;

    @LastModifiedDate
    private LocalDateTime dataAtualizacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cadastrado_por")
    private Usuario cadastradoPor;

    public enum CategoriaItem {
        ALIMENTO, HIGIENE, VESTUARIO, MEDICAMENTO, MATERIAL_ESCOLAR, OUTROS
    }

    public boolean isEstoqueBaixo() {
        return quantidadeAtual <= quantidadeMinima;
    }
}
