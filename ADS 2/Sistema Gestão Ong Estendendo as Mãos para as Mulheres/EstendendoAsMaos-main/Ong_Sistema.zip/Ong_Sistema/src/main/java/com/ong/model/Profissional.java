package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity
@Table(name = "profissionais")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Profissional {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nomeCompleto;

    @Column(unique = true, nullable = false)
    private String email;

    private String telefone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoProfissional tipo;

    private String numeroRegistro;
    private String especialidade;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private StatusProfissional status = StatusProfissional.ATIVO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoVinculo tipoVinculo;

    @Column(columnDefinition = "TEXT")
    private String observacoes;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCadastro;

    @LastModifiedDate
    private LocalDateTime dataAtualizacao;

    public enum TipoProfissional {
        PSICOLOGO, ADVOGADO, ASSISTENTE_SOCIAL, MEDICO, ENFERMEIRO, PEDAGOGO, OUTRO
    }

    public enum StatusProfissional {
        ATIVO, INATIVO, LICENCA
    }

    public enum TipoVinculo {
        CLT, VOLUNTARIO, PRESTADOR_SERVICO
    }
}
