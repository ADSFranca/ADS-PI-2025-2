package com.ong.controller;

import com.ong.dto.AtendimentoDTO;
import com.ong.service.AtendimentoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/atendimentos")
@RequiredArgsConstructor
public class AtendimentoController {

    private final AtendimentoService service;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<AtendimentoDTO>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/beneficiaria/{id}")
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<AtendimentoDTO>> listarPorBeneficiaria(@PathVariable Long id) {
        return ResponseEntity.ok(service.listarPorBeneficiaria(id));
    }

    @GetMapping("/profissional/{id}")
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<AtendimentoDTO>> listarPorProfissional(@PathVariable Long id) {
        return ResponseEntity.ok(service.listarPorProfissional(id));
    }

    @GetMapping("/profissional/{id}/agenda")
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<AtendimentoDTO>> listarAgenda(
            @PathVariable Long id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        return ResponseEntity.ok(service.listarAgendaDoProfissional(id, dataInicio, dataFim));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_ESCRITA', 'ADMIN')")
    public ResponseEntity<AtendimentoDTO> agendar(@Valid @RequestBody AtendimentoDTO dto) {
        return ResponseEntity.ok(service.agendar(dto));
    }

    @PutMapping("/{id}/registrar")
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_ESCRITA', 'ADMIN')")
    public ResponseEntity<AtendimentoDTO> registrar(@PathVariable Long id, @Valid @RequestBody AtendimentoDTO dto) {
        return ResponseEntity.ok(service.registrarAtendimento(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ATENDIMENTO_EXCLUSAO', 'ADMIN')")
    public ResponseEntity<Void> cancelar(@PathVariable Long id) {
        service.cancelar(id);
        return ResponseEntity.noContent().build();
    }
}
