package com.ong.service;

import com.ong.dto.EnderecoViaCepDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class ViaCepService {

    private static final String VIACEP_URL = "https://viacep.com.br/ws/{cep}/json/";

    public EnderecoViaCepDTO buscarEnderecoPorCep(String cep) {
        try {
            // Remove caracteres não numéricos do CEP
            String cepLimpo = cep.replaceAll("[^0-9]", "");

            if (cepLimpo.length() != 8) {
                throw new RuntimeException("CEP inválido. Deve conter 8 dígitos.");
            }

            RestTemplate restTemplate = new RestTemplate();
            EnderecoViaCepDTO endereco = restTemplate.getForObject(
                VIACEP_URL, 
                EnderecoViaCepDTO.class, 
                cepLimpo
            );

            if (endereco != null && Boolean.TRUE.equals(endereco.getErro())) {
                throw new RuntimeException("CEP não encontrado.");
            }

            return endereco;

        } catch (Exception e) {
            log.error("Erro ao buscar CEP: {}", e.getMessage());
            throw new RuntimeException("Erro ao consultar CEP: " + e.getMessage());
        }
    }
}
