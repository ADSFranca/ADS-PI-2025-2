package com.ong.repository;

import com.ong.model.Campanha;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface CampanhaRepository extends JpaRepository<Campanha, Long> {
    List<Campanha> findByStatus(Campanha.StatusCampanha status);

    @Query("SELECT c FROM Campanha c WHERE c.dataInicio <= :hoje AND c.dataFim >= :hoje AND c.status = 'ATIVA'")
    List<Campanha> findCampanhasAtivas(LocalDate hoje);
}
