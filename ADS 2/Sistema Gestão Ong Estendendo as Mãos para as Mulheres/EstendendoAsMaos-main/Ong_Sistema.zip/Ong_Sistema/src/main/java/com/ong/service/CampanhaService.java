package com.ong.service;

import com.ong.dto.CampanhaDTO;
import com.ong.model.Campanha;
import com.ong.repository.CampanhaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CampanhaService {

    private final CampanhaRepository repository;

    @Transactional(readOnly = true)
    public List<CampanhaDTO> listarTodas() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<CampanhaDTO> listarAtivas() {
        return repository.findCampanhasAtivas(LocalDate.now()).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CampanhaDTO buscarPorId(Long id) {
        Campanha campanha = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Campanha não encontrada"));
        return toDTO(campanha);
    }

    @Transactional
    public CampanhaDTO criar(CampanhaDTO dto) {
        Campanha campanha = Campanha.builder()
            .titulo(dto.getTitulo())
            .descricao(dto.getDescricao())
            .dataInicio(dto.getDataInicio())
            .dataFim(dto.getDataFim())
            .metaFinanceira(dto.getMetaFinanceira())
            .imagemUrl(dto.getImagemUrl())
            .build();

        campanha = repository.save(campanha);
        return toDTO(campanha);
    }

    @Transactional
    public CampanhaDTO ativar(Long id) {
        Campanha campanha = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Campanha não encontrada"));

        campanha.setStatus(Campanha.StatusCampanha.ATIVA);
        campanha = repository.save(campanha);
        return toDTO(campanha);
    }

    @Transactional
    public CampanhaDTO encerrar(Long id) {
        Campanha campanha = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Campanha não encontrada"));

        campanha.setStatus(Campanha.StatusCampanha.ENCERRADA);
        campanha = repository.save(campanha);
        return toDTO(campanha);
    }

    @Transactional
    public void adicionarDoacao(Long id, BigDecimal valor) {
        Campanha campanha = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Campanha não encontrada"));

        campanha.setValorArrecadado(campanha.getValorArrecadado().add(valor));
        repository.save(campanha);
    }

    private CampanhaDTO toDTO(Campanha c) {
        CampanhaDTO dto = new CampanhaDTO();
        dto.setId(c.getId());
        dto.setTitulo(c.getTitulo());
        dto.setDescricao(c.getDescricao());
        dto.setDataInicio(c.getDataInicio());
        dto.setDataFim(c.getDataFim());
        dto.setMetaFinanceira(c.getMetaFinanceira());
        dto.setValorArrecadado(c.getValorArrecadado());
        dto.setStatus(c.getStatus().name());
        dto.setImagemUrl(c.getImagemUrl());

        // Calcular percentual atingido
        if (c.getMetaFinanceira() != null && c.getMetaFinanceira().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal percentual = c.getValorArrecadado()
                .multiply(BigDecimal.valueOf(100))
                .divide(c.getMetaFinanceira(), 2, RoundingMode.HALF_UP);
            dto.setPercentualAtingido(percentual.doubleValue());
        }

        return dto;
    }
}
