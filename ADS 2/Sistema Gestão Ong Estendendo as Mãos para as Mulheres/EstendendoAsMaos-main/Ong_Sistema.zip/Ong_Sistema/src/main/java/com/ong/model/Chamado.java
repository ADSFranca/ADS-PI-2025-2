package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity
@Table(name = "chamados")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Chamado {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String descricao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Categoria categoria;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Prioridade prioridade;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Status status = Status.ABERTO;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "criado_por")
    private Usuario criadoPor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "atribuido_para")
    private Usuario atribuidoPara;

    @Column(columnDefinition = "TEXT")
    private String resolucao;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataAbertura;

    @LastModifiedDate
    private LocalDateTime dataAtualizacao;

    private LocalDateTime dataFechamento;

    public enum Categoria {
        TECNICO, ADMINISTRATIVO, ATENDIMENTO, OUTRO
    }

    public enum Prioridade {
        BAIXA, MEDIA, ALTA, URGENTE
    }

    public enum Status {
        ABERTO, EM_ANDAMENTO, AGUARDANDO, RESOLVIDO, FECHADO
    }
}
