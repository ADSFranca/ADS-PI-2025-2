package com.ong.controller;

import com.ong.dto.VoluntarioDTO;
import com.ong.service.VoluntarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/voluntarios")
@RequiredArgsConstructor
public class VoluntarioController {

    private final VoluntarioService service;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<VoluntarioDTO>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/pendentes")
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<VoluntarioDTO>> listarPendentes() {
        return ResponseEntity.ok(service.listarPendentes());
    }

    @GetMapping("/ativos")
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_LEITURA', 'ADMIN')")
    public ResponseEntity<List<VoluntarioDTO>> listarAtivos() {
        return ResponseEntity.ok(service.listarAtivos());
    }

    @PostMapping("/public/candidatar")
    public ResponseEntity<VoluntarioDTO> candidatar(@Valid @RequestBody VoluntarioDTO dto) {
        return ResponseEntity.ok(service.candidatar(dto));
    }

    @PutMapping("/{id}/aprovar")
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_ESCRITA', 'ADMIN')")
    public ResponseEntity<VoluntarioDTO> aprovar(@PathVariable Long id) {
        return ResponseEntity.ok(service.aprovar(id));
    }

    @PutMapping("/{id}/rejeitar")
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_ESCRITA', 'ADMIN')")
    public ResponseEntity<VoluntarioDTO> rejeitar(@PathVariable Long id) {
        return ResponseEntity.ok(service.rejeitar(id));
    }

    @PutMapping("/{id}/horas")
    @PreAuthorize("hasAnyAuthority('VOLUNTARIO_ESCRITA', 'ADMIN')")
    public ResponseEntity<VoluntarioDTO> registrarHoras(@PathVariable Long id, @RequestParam Integer horas) {
        return ResponseEntity.ok(service.registrarHoras(id, horas));
    }
}
