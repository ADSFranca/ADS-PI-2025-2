package com.ong.service;

import com.ong.dto.LogAuditoriaDTO;
import com.ong.model.LogAuditoria;
import com.ong.model.Usuario;
import com.ong.repository.LogAuditoriaRepository;
import com.ong.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LogAuditoriaService {

    private final LogAuditoriaRepository repository;
    private final UsuarioRepository usuarioRepository;

    @Transactional
    public void registrar(Long idUsuario, LogAuditoria.TipoAcao acao, String entidade, 
                         Long idEntidade, String detalhes, String ip) {
        Usuario usuario = null;
        if (idUsuario != null) {
            usuario = usuarioRepository.findById(idUsuario).orElse(null);
        }

        LogAuditoria log = LogAuditoria.builder()
            .usuario(usuario)
            .acao(acao)
            .entidade(entidade)
            .idEntidade(idEntidade)
            .detalhes(detalhes)
            .ipOrigem(ip)
            .build();

        repository.save(log);
    }

    @Transactional(readOnly = true)
    public List<LogAuditoriaDTO> listarRecentes() {
        return repository.findRecentLogs().stream()
            .limit(100)
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<LogAuditoriaDTO> buscarPorPeriodo(LocalDateTime inicio, LocalDateTime fim) {
        return repository.findByDataHoraBetween(inicio, fim).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    private LogAuditoriaDTO toDTO(LogAuditoria l) {
        LogAuditoriaDTO dto = new LogAuditoriaDTO();
        dto.setId(l.getId());
        if (l.getUsuario() != null) {
            dto.setIdUsuario(l.getUsuario().getId());
            dto.setNomeUsuario(l.getUsuario().getNomeCompleto());
        }
        dto.setAcao(l.getAcao().name());
        dto.setEntidade(l.getEntidade());
        dto.setIdEntidade(l.getIdEntidade());
        dto.setDetalhes(l.getDetalhes());
        dto.setIpOrigem(l.getIpOrigem());
        dto.setDataHora(l.getDataHora());
        return dto;
    }
}
