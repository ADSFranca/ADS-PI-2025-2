package com.ong.repository;

import com.ong.model.Voluntario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface VoluntarioRepository extends JpaRepository<Voluntario, Long> {
    List<Voluntario> findByStatus(Voluntario.StatusVoluntario status);
    List<Voluntario> findByAreaInteresse(String areaInteresse);
}
