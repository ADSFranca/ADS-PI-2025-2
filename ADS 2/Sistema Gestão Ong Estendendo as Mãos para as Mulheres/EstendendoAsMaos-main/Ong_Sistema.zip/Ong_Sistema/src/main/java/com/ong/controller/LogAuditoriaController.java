package com.ong.controller;

import com.ong.dto.LogAuditoriaDTO;
import com.ong.service.LogAuditoriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/auditoria")
@RequiredArgsConstructor
public class LogAuditoriaController {

    private final LogAuditoriaService service;

    @GetMapping("/recentes")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<LogAuditoriaDTO>> listarRecentes() {
        return ResponseEntity.ok(service.listarRecentes());
    }

    @GetMapping("/periodo")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<LogAuditoriaDTO>> buscarPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        return ResponseEntity.ok(service.buscarPorPeriodo(inicio, fim));
    }
}
