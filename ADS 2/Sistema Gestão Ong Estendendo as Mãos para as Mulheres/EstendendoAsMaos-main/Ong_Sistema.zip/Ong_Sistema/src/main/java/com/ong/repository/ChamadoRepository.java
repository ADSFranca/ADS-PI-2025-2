package com.ong.repository;

import com.ong.model.Chamado;
import com.ong.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ChamadoRepository extends JpaRepository<Chamado, Long> {
    List<Chamado> findByStatus(Chamado.Status status);
    List<Chamado> findByCriadoPor(Usuario usuario);
    List<Chamado> findByAtribuidoPara(Usuario usuario);

    @Query("SELECT c FROM Chamado c WHERE c.status IN ('ABERTO', 'EM_ANDAMENTO')")
    List<Chamado> findChamadosAtivos();

    @Query("SELECT COUNT(c) FROM Chamado c WHERE c.status = 'ABERTO'")
    Long contarChamadosAbertos();
}
