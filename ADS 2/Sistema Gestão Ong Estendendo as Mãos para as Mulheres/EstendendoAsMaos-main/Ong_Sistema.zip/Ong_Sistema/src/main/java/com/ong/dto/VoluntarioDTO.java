package com.ong.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class VoluntarioDTO {
    private Long id;

    @NotBlank
    private String nomeCompleto;

    @NotBlank @Email
    private String email;

    private String telefone;
    private String areaInteresse;
    private String disponibilidade;
    private String status;
    private Integer horasTrabalhadas;
    private String observacoes;
}
