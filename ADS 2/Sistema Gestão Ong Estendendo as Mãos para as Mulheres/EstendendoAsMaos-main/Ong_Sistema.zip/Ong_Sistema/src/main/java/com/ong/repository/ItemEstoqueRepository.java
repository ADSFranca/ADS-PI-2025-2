package com.ong.repository;

import com.ong.model.ItemEstoque;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ItemEstoqueRepository extends JpaRepository<ItemEstoque, Long> {

    Optional<ItemEstoque> findByCodigoBarras(String codigoBarras);

    List<ItemEstoque> findByCategoria(ItemEstoque.CategoriaItem categoria);

    @Query("SELECT i FROM ItemEstoque i WHERE i.quantidadeAtual <= i.quantidadeMinima")
    List<ItemEstoque> findItensAbaixoEstoqueMinimo();

    @Query("SELECT i FROM ItemEstoque i " +
           "WHERE i.dataValidade IS NOT NULL " +
           "AND i.dataValidade <= :limite")
    List<ItemEstoque> findItensProximosVencimento(@Param("limite") LocalDate limite);
}
