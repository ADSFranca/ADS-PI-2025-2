package com.ong.controller;

import com.ong.dto.ProfissionalDTO;
import com.ong.service.ProfissionalService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/profissionais")
@RequiredArgsConstructor
public class ProfissionalController {

    private final ProfissionalService service;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_LEITURA', 'ADMIN')")
    public ResponseEntity<List<ProfissionalDTO>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/ativos")
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_LEITURA', 'ADMIN')")
    public ResponseEntity<List<ProfissionalDTO>> listarAtivos() {
        return ResponseEntity.ok(service.listarAtivos());
    }

    @GetMapping("/tipo/{tipo}")
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_LEITURA', 'ADMIN')")
    public ResponseEntity<List<ProfissionalDTO>> listarPorTipo(@PathVariable String tipo) {
        return ResponseEntity.ok(service.listarPorTipo(tipo));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_LEITURA', 'ADMIN')")
    public ResponseEntity<ProfissionalDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_ESCRITA', 'ADMIN')")
    public ResponseEntity<ProfissionalDTO> criar(@Valid @RequestBody ProfissionalDTO dto) {
        return ResponseEntity.ok(service.criar(dto));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_ESCRITA', 'ADMIN')")
    public ResponseEntity<ProfissionalDTO> atualizar(@PathVariable Long id, @Valid @RequestBody ProfissionalDTO dto) {
        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('PROFISSIONAL_EXCLUSAO', 'ADMIN')")
    public ResponseEntity<Void> inativar(@PathVariable Long id) {
        service.inativar(id);
        return ResponseEntity.noContent().build();
    }
}
