package com.ong.controller;

import com.ong.dto.BeneficiariaDTO;
import com.ong.service.BeneficiariaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/beneficiarias")
@RequiredArgsConstructor
public class BeneficiariaController {

    private final BeneficiariaService service;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('BENEFICIARIA_LEITURA', 'ADMIN')")
    public ResponseEntity<List<BeneficiariaDTO>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('BENEFICIARIA_LEITURA', 'ADMIN')")
    public ResponseEntity<BeneficiariaDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('BENEFICIARIA_ESCRITA', 'ADMIN')")
    public ResponseEntity<BeneficiariaDTO> criar(@Valid @RequestBody BeneficiariaDTO dto) {
        return ResponseEntity.ok(service.criar(dto));
    }
}
