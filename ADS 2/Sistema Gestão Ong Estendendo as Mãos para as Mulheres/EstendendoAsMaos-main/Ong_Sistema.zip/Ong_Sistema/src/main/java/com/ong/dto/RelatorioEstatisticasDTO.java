package com.ong.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RelatorioEstatisticasDTO {

    // Beneficiárias
    private Long totalBeneficiarias;
    private Long beneficiariasAtivas;

    // Profissionais
    private Long totalProfissionais;
    private Long profissionaisAtivos;

    // Voluntários
    private Long totalVoluntarios;
    private Long voluntariosAtivos;
    private Integer horasTotaisVoluntariado;

    // Atendimentos
    private Long totalAtendimentos;
    private Long atendimentosRealizados;

    // Campanhas
    private Long totalCampanhas;
    private Long campanhasAtivas;

    // Doações
    private BigDecimal totalDoacoes;
    private BigDecimal totalArrecadadoCampanhas;

    // Chamados
    private Long chamadosAbertos;
    private Long chamadosResolvidos;

    // Estoque
    private Long itensEstoqueBaixo;

    // Dados para gráficos / agregados
    private Map<String, Long> atendimentosPorTipo;
    private Map<String, Long> beneficiariasPorStatus;
    private Map<String, BigDecimal> doacoesPorMes;
}
