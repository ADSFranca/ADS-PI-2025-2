package com.ong.service;

import com.ong.dto.AtendimentoDTO;
import com.ong.model.Atendimento;
import com.ong.model.Beneficiaria;
import com.ong.model.Profissional;
import com.ong.repository.AtendimentoRepository;
import com.ong.repository.BeneficiariaRepository;
import com.ong.repository.ProfissionalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AtendimentoService {

    private final AtendimentoRepository repository;
    private final BeneficiariaRepository beneficiariaRepository;
    private final ProfissionalRepository profissionalRepository;

    @Transactional(readOnly = true)
    public List<AtendimentoDTO> listarTodos() {
        return repository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AtendimentoDTO> listarPorBeneficiaria(Long idBeneficiaria) {
        Beneficiaria beneficiaria = beneficiariaRepository.findById(idBeneficiaria)
            .orElseThrow(() -> new RuntimeException("Beneficiária não encontrada"));
        return repository.findByBeneficiaria(beneficiaria).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AtendimentoDTO> listarPorProfissional(Long idProfissional) {
        Profissional profissional = profissionalRepository.findById(idProfissional)
            .orElseThrow(() -> new RuntimeException("Profissional não encontrado"));
        return repository.findByProfissional(profissional).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AtendimentoDTO> listarAgendaDoProfissional(Long idProfissional, LocalDateTime dataInicio, LocalDateTime dataFim) {
        return repository.buscarAgendaDoProfissional(idProfissional, dataInicio, dataFim).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    @Transactional
    public AtendimentoDTO agendar(AtendimentoDTO dto) {
        Beneficiaria beneficiaria = beneficiariaRepository.findById(dto.getIdBeneficiaria())
            .orElseThrow(() -> new RuntimeException("Beneficiária não encontrada"));

        Profissional profissional = profissionalRepository.findById(dto.getIdProfissional())
            .orElseThrow(() -> new RuntimeException("Profissional não encontrado"));

        Atendimento atendimento = Atendimento.builder()
            .beneficiaria(beneficiaria)
            .profissional(profissional)
            .dataHoraAtendimento(dto.getDataHoraAtendimento())
            .tipoAtendimento(Atendimento.TipoAtendimento.valueOf(dto.getTipoAtendimento().toUpperCase()))
            .observacoes(dto.getObservacoes())
            .build();

        atendimento = repository.save(atendimento);
        return toDTO(atendimento);
    }

    @Transactional
    public AtendimentoDTO registrarAtendimento(Long id, AtendimentoDTO dto) {
        Atendimento atendimento = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Atendimento não encontrado"));

        atendimento.setStatus(Atendimento.StatusAtendimento.REALIZADO);
        atendimento.setRelatorioCriptografado(dto.getRelatorio()); // TODO: Criptografar
        atendimento.setProximaSessao(dto.getProximaSessao());

        atendimento = repository.save(atendimento);
        return toDTO(atendimento);
    }

    @Transactional
    public void cancelar(Long id) {
        Atendimento atendimento = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Atendimento não encontrado"));
        atendimento.setStatus(Atendimento.StatusAtendimento.CANCELADO);
        repository.save(atendimento);
    }

    private AtendimentoDTO toDTO(Atendimento a) {
        AtendimentoDTO dto = new AtendimentoDTO();
        dto.setId(a.getId());
        dto.setIdBeneficiaria(a.getBeneficiaria().getId());
        dto.setIdProfissional(a.getProfissional().getId());
        dto.setNomeBeneficiaria(a.getBeneficiaria().getNomeCompleto());
        dto.setNomeProfissional(a.getProfissional().getNomeCompleto());
        dto.setDataHoraAtendimento(a.getDataHoraAtendimento());
        dto.setTipoAtendimento(a.getTipoAtendimento().name());
        dto.setStatus(a.getStatus().name());
        dto.setProximaSessao(a.getProximaSessao());
        dto.setObservacoes(a.getObservacoes());
        return dto;
    }
}
