package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "voluntarios")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Voluntario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nomeCompleto;

    @Column(unique = true, nullable = false)
    private String email;

    private String telefone;

    private String areaInteresse;

    private String disponibilidade;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private StatusVoluntario status = StatusVoluntario.PENDENTE;

    @Column(name = "horas_trabalhadas")
    @Builder.Default
    private Integer horasTrabalhadas = 0;

    @Column(columnDefinition = "TEXT")
    private String observacoes;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCadastro;

    private LocalDateTime dataAprovacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "aprovado_por")
    private Usuario aprovadoPor;

    public enum StatusVoluntario {
        PENDENTE, APROVADO, ATIVO, INATIVO, REJEITADO
    }
}
