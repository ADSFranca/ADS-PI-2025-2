package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "doacoes")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Doacao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal valorDoacao;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Status status = Status.PENDENTE;

    private String codigoTransacao;
    private String nomeDoador;
    private String emailDoador;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataDoacao;

    public enum Status { PENDENTE, CONFIRMADA, CANCELADA }
}
