package com.ong.service;

import com.ong.dto.RelatorioEstatisticasDTO;
import com.ong.model.*;
import com.ong.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class RelatorioService {

    private final BeneficiariaRepository beneficiariaRepository;
    private final ProfissionalRepository profissionalRepository;
    private final VoluntarioRepository voluntarioRepository;
    private final AtendimentoRepository atendimentoRepository;
    private final CampanhaRepository campanhaRepository;
    private final DoacaoRepository doacaoRepository;
    private final ChamadoRepository chamadoRepository;
    private final ItemEstoqueRepository itemEstoqueRepository;

    @Transactional(readOnly = true)
    public RelatorioEstatisticasDTO gerarEstatisticasGerais() {
        RelatorioEstatisticasDTO relatorio = new RelatorioEstatisticasDTO();

        // Beneficiárias
        relatorio.setTotalBeneficiarias(beneficiariaRepository.count());
        relatorio.setBeneficiariasAtivas(
            beneficiariaRepository.findAll().stream()
                .filter(b -> b.getStatus() == Beneficiaria.Status.ATIVA)
                .count()
        );

        // Profissionais
        relatorio.setTotalProfissionais(profissionalRepository.count());
        relatorio.setProfissionaisAtivos(
            (long) profissionalRepository.findByStatus(Profissional.StatusProfissional.ATIVO).size()
        );

        // Voluntários
        relatorio.setTotalVoluntarios(voluntarioRepository.count());
        relatorio.setVoluntariosAtivos(
            (long) voluntarioRepository.findByStatus(Voluntario.StatusVoluntario.ATIVO).size()
        );

        Integer horasTotais = voluntarioRepository.findAll().stream()
            .mapToInt(v -> v.getHorasTrabalhadas() != null ? v.getHorasTrabalhadas() : 0)
            .sum();
        relatorio.setHorasTotaisVoluntariado(horasTotais);

        // Atendimentos
        relatorio.setTotalAtendimentos(atendimentoRepository.count());
        relatorio.setAtendimentosRealizados(
            (long) atendimentoRepository.findByStatus(Atendimento.StatusAtendimento.REALIZADO).size()
        );

        // Campanhas
        relatorio.setTotalCampanhas(campanhaRepository.count());
        relatorio.setCampanhasAtivas(
            (long) campanhaRepository.findByStatus(Campanha.StatusCampanha.ATIVA).size()
        );

        // Doações
        BigDecimal totalDoacoes = doacaoRepository.somarTotalDoacoes();
        relatorio.setTotalDoacoes(totalDoacoes != null ? totalDoacoes : BigDecimal.ZERO);

        BigDecimal totalCampanhas = campanhaRepository.findAll().stream()
            .map(c -> c.getValorArrecadado() != null ? c.getValorArrecadado() : BigDecimal.ZERO)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        relatorio.setTotalArrecadadoCampanhas(totalCampanhas);

        // Chamados
        relatorio.setChamadosAbertos(chamadoRepository.contarChamadosAbertos());
        relatorio.setChamadosResolvidos(
            (long) chamadoRepository.findByStatus(Chamado.Status.RESOLVIDO).size()
        );

        // Estoque
        relatorio.setItensEstoqueBaixo(
            (long) itemEstoqueRepository.findItensAbaixoEstoqueMinimo().size()
        );

        // Dados para gráficos
        relatorio.setAtendimentosPorTipo(contarAtendimentosPorTipo());

        return relatorio;
    }

    private Map<String, Long> contarAtendimentosPorTipo() {
        Map<String, Long> resultado = new HashMap<>();
        for (Atendimento.TipoAtendimento tipo : Atendimento.TipoAtendimento.values()) {
            long count = atendimentoRepository.findAll().stream()
                .filter(a -> a.getTipoAtendimento() == tipo)
                .count();
            resultado.put(tipo.name(), count);
        }
        return resultado;
    }
}
