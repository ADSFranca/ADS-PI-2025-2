package com.ong.repository;

import com.ong.model.Profissional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProfissionalRepository extends JpaRepository<Profissional, Long> {
    List<Profissional> findByStatus(Profissional.StatusProfissional status);
    List<Profissional> findByTipo(Profissional.TipoProfissional tipo);
    List<Profissional> findByTipoAndStatus(Profissional.TipoProfissional tipo, Profissional.StatusProfissional status);
}
