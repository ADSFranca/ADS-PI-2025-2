package com.ong.repository;

import com.ong.model.LogAuditoria;
import com.ong.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LogAuditoriaRepository extends JpaRepository<LogAuditoria, Long> {
    List<LogAuditoria> findByUsuario(Usuario usuario);
    List<LogAuditoria> findByEntidadeAndIdEntidade(String entidade, Long idEntidade);
    List<LogAuditoria> findByDataHoraBetween(LocalDateTime inicio, LocalDateTime fim);

    @Query("SELECT l FROM LogAuditoria l ORDER BY l.dataHora DESC")
    List<LogAuditoria> findRecentLogs();
}
