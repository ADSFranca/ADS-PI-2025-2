package com.ong.service;

import com.ong.dto.ItemEstoqueDTO;
import com.ong.model.ItemEstoque;
import com.ong.repository.ItemEstoqueRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ItemEstoqueService {

    private final ItemEstoqueRepository repository;

    @Transactional(readOnly = true)
    public List<ItemEstoqueDTO> listarTodos() {
        return repository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ItemEstoqueDTO> listarEstoqueBaixo() {
        return repository.findItensAbaixoEstoqueMinimo().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ItemEstoqueDTO> listarProximosVencimento() {
        LocalDate limite = LocalDate.now().plusDays(30);
        return repository.findItensProximosVencimento(limite).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ItemEstoqueDTO buscarPorCodigoBarras(String codigoBarras) {
        ItemEstoque item = repository.findByCodigoBarras(codigoBarras)
                .orElseThrow(() -> new RuntimeException("Item não encontrado"));
        return toDTO(item);
    }

    @Transactional
    public ItemEstoqueDTO criar(ItemEstoqueDTO dto) {
        ItemEstoque item = ItemEstoque.builder()
                .codigoBarras(dto.getCodigoBarras())
                .nomeItem(dto.getNomeItem())
                .descricao(dto.getDescricao())
                .categoria(ItemEstoque.CategoriaItem.valueOf(dto.getCategoria().toUpperCase()))
                .quantidadeAtual(dto.getQuantidadeAtual())
                .quantidadeMinima(dto.getQuantidadeMinima())
                .dataValidade(dto.getDataValidade())
                .localArmazenamento(dto.getLocalArmazenamento())
                .build();

        item = repository.save(item);
        return toDTO(item);
    }

    @Transactional
    public ItemEstoqueDTO adicionarQuantidade(Long id, Integer quantidade) {
        ItemEstoque item = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item não encontrado"));

        item.setQuantidadeAtual(item.getQuantidadeAtual() + quantidade);
        item = repository.save(item);
        return toDTO(item);
    }

    @Transactional
    public ItemEstoqueDTO removerQuantidade(Long id, Integer quantidade) {
        ItemEstoque item = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item não encontrado"));

        if (item.getQuantidadeAtual() < quantidade) {
            throw new RuntimeException("Quantidade insuficiente em estoque");
        }

        item.setQuantidadeAtual(item.getQuantidadeAtual() - quantidade);
        item = repository.save(item);
        return toDTO(item);
    }

    private ItemEstoqueDTO toDTO(ItemEstoque i) {
        ItemEstoqueDTO dto = new ItemEstoqueDTO();
        dto.setId(i.getId());
        dto.setCodigoBarras(i.getCodigoBarras());
        dto.setNomeItem(i.getNomeItem());
        dto.setDescricao(i.getDescricao());
        dto.setCategoria(i.getCategoria().name());
        dto.setQuantidadeAtual(i.getQuantidadeAtual());
        dto.setQuantidadeMinima(i.getQuantidadeMinima());
        dto.setDataValidade(i.getDataValidade());
        dto.setLocalArmazenamento(i.getLocalArmazenamento());
        dto.setEstoqueBaixo(i.isEstoqueBaixo());
        return dto;
    }
}
