package com.ong.controller;

import com.ong.dto.RelatorioEstatisticasDTO;
import com.ong.service.RelatorioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/relatorios")
@RequiredArgsConstructor
public class RelatorioController {

    private final RelatorioService service;

    @GetMapping("/estatisticas")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'RELATORIO_LEITURA')")
    public ResponseEntity<RelatorioEstatisticasDTO> gerarEstatisticas() {
        return ResponseEntity.ok(service.gerarEstatisticasGerais());
    }
}
