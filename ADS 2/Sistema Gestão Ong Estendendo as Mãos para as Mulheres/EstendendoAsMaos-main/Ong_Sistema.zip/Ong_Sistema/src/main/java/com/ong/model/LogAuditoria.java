package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity
@Table(name = "logs_auditoria")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class LogAuditoria {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoAcao acao;

    @Column(nullable = false)
    private String entidade;

    private Long idEntidade;

    @Column(columnDefinition = "TEXT")
    private String detalhes;

    private String ipOrigem;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataHora;

    public enum TipoAcao {
        CRIAR, ATUALIZAR, DELETAR, LOGIN, LOGOUT, ACESSO
    }
}
