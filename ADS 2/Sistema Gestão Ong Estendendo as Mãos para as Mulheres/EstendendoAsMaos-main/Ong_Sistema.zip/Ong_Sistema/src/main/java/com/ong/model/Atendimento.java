package com.ong.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "atendimentos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Atendimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_beneficiaria", nullable = false)
    private Beneficiaria beneficiaria;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_profissional", nullable = false)
    private Profissional profissional;

    @Column(nullable = false)
    private LocalDateTime dataHoraAtendimento;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoAtendimento tipoAtendimento;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private StatusAtendimento status = StatusAtendimento.AGENDADO;

    @Column(columnDefinition = "TEXT")
    private String relatorioCriptografado;

    private LocalDateTime proximaSessao;

    @Column(columnDefinition = "TEXT")
    private String observacoes;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCriacao;

    public enum TipoAtendimento {
        PSICOLOGICO, JURIDICO, ASSISTENCIA_SOCIAL, MEDICO, PEDAGOGICO, GRUPO_APOIO
    }

    public enum StatusAtendimento {
        AGENDADO, REALIZADO, CANCELADO, FALTOU
    }
}
