# Sistema de Gestão para ONG

Sistema completo de gestão para ONGs - Java + Spring Boot + PostgreSQL

## 🚀 Tecnologias

- Java 17
- Spring Boot 3.2.0
- PostgreSQL 14+
- Spring Security + JWT
- Flyway (Migrations)
- Redis (Cache)
- Lombok
- Maven

## 📋 Pré-requisitos

- JDK 17+
- PostgreSQL 14+
- Maven 3.8+
- Redis 6+ (opcional)

## 🔧 Configuração

### 1. Criar Banco de Dados

```sql
CREATE DATABASE sistema_ong;
CREATE USER ong_user WITH PASSWORD 'sua_senha';
GRANT ALL PRIVILEGES ON DATABASE sistema_ong TO ong_user;
```

### 2. Configurar application.properties

Edite `src/main/resources/application.properties` e configure:
- Credenciais do PostgreSQL
- Chave JWT (IMPORTANTE: mudar em produção!)
- Configurações de email

### 3. Executar o Projeto

```bash
# Com Maven
mvn clean install
mvn spring-boot:run

# Ou executando o JAR
java -jar target/sistema-gestao-ong-1.0.0.jar
```

## 📚 Módulos do Sistema

1. **Gestão de Usuários** - Autenticação JWT, permissões RBAC
2. **Gestão de Beneficiárias** - Cadastro com criptografia LGPD
3. **Profissionais e Atendimentos** - Agendamento e registro
4. **Doações** - Financeiras e produtos
5. **Estoque** - Controle completo com código de barras
6. **Help Desk** - Sistema de chamados
7. **Voluntariado** - Gestão de voluntários
8. **Campanhas** - Criação e acompanhamento
9. **Relatórios** - Dashboard e transparência
10. **Auditoria** - Logs completos de ações

## 🔐 Endpoints da API

### Autenticação
- POST `/api/auth/login` - Login
- POST `/api/auth/refresh` - Refresh token

### Usuários
- GET `/api/usuarios` - Listar usuários
- POST `/api/usuarios` - Criar usuário
- GET `/api/usuarios/{id}` - Buscar usuário
- PUT `/api/usuarios/{id}` - Atualizar usuário
- DELETE `/api/usuarios/{id}` - Deletar usuário

### Beneficiárias
- GET `/api/beneficiarias` - Listar beneficiárias
- POST `/api/beneficiarias` - Cadastrar beneficiária
- GET `/api/beneficiarias/{id}` - Buscar beneficiária
- PUT `/api/beneficiarias/{id}` - Atualizar beneficiária

### Doações
- GET `/api/doacoes` - Listar doações
- POST `/api/doacoes/public/iniciar` - Iniciar doação (público)
- GET `/api/doacoes/{id}` - Buscar doação

### Transparência (Público)
- GET `/api/transparencia/indicadores` - Indicadores públicos
- GET `/api/transparencia/relatorios` - Relatórios públicos

## 🛡️ Segurança

- Autenticação JWT
- Criptografia de dados sensíveis (AES-256)
- Conformidade LGPD
- Auditoria completa de ações
- Rate limiting

## 📊 Banco de Dados

O sistema usa Flyway para migrations automáticas. As tabelas serão criadas automaticamente na primeira execução.

## 🧪 Testes

```bash
mvn test
```

## 📦 Build para Produção

```bash
mvn clean package -DskipTests
```

O JAR estará em `target/sistema-gestao-ong-1.0.0.jar`

## 👥 Suporte

Para suporte, envie email para: suporte@suaong.org

## 📝 Licença

MIT License

---

Desenvolvido com ❤️ para fazer a diferença na vida de mulheres em situação de vulnerabilidade.
