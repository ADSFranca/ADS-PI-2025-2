import { useQuery } from '@tanstack/react-query'
import api from '../services/api'

export default function Campanhas() {
  const { data: campanhas, isLoading } = useQuery({
    queryKey: ['campanhas'],
    queryFn: () => api.get('/campanhas').then(r => r.data)
  })

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Campanhas</h1>
          <p>Acompanhe as campanhas da ONG</p>
        </div>
      </div>

      <div className="dashboard-grid">
        {campanhas?.map((c) => (
          <div key={c.id} className="card">
            <h3 style={{ color: 'var(--primary-purple)', marginBottom: '1rem' }}>
              {c.titulo}
            </h3>
            <p style={{ color: 'var(--gray)', marginBottom: '1rem' }}>
              {c.descricao}
            </p>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span>Meta:</span>
              <strong>R$ {c.metaFinanceira?.toLocaleString('pt-BR')}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <span>Arrecadado:</span>
              <strong style={{ color: 'var(--orange-hover)' }}>
                R$ {c.valorArrecadado?.toLocaleString('pt-BR')}
              </strong>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${c.percentualAtingido || 0}%` }}
              />
            </div>
            <p style={{ textAlign: 'center', marginTop: '0.5rem', fontSize: '0.875rem' }}>
              {c.percentualAtingido?.toFixed(1)}% atingido
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
