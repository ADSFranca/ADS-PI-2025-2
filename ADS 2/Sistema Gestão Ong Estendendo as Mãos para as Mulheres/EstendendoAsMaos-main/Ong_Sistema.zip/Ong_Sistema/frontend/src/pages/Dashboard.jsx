import { useQuery } from '@tanstack/react-query'
import api from '../services/api'
import { FiUsers, FiHeart, FiTarget, FiDollarSign } from 'react-icons/fi'
import './Dashboard.css'

export default function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: async () => {
      const [beneficiarias, voluntarios, campanhas, totalDoacoes] = await Promise.all([
        api.get('/beneficiarias').then(r => r.data.length),
        api.get('/voluntarios').then(r => r.data.length),
        api.get('/campanhas/ativas').then(r => r.data.length),
        api.get('/doacoes/public/total').then(r => r.data)
      ])
      return { beneficiarias, voluntarios, campanhas, totalDoacoes }
    }
  })

  const cards = [
    {
      title: 'Beneficiárias',
      value: stats?.beneficiarias || 0,
      icon: FiUsers,
      color: 'var(--primary-purple)'
    },
    {
      title: 'Voluntários Ativos',
      value: stats?.voluntarios || 0,
      icon: FiHeart,
      color: 'var(--orange-hover)'
    },
    {
      title: 'Campanhas Ativas',
      value: stats?.campanhas || 0,
      icon: FiTarget,
      color: 'var(--secondary-purple)'
    },
    {
      title: 'Total em Doações',
      value: `R$ ${(stats?.totalDoacoes || 0).toLocaleString('pt-BR')}`,
      icon: FiDollarSign,
      color: '#10B981'
    }
  ]

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <p>Visão geral do sistema</p>
      </div>

      <div className="dashboard-grid">
        {cards.map((card, index) => (
          <div key={index} className="dashboard-card">
            <div className="dashboard-card-icon" style={{ backgroundColor: card.color }}>
              <card.icon size={28} color="white" />
            </div>
            <div className="dashboard-card-content">
              <h3>{card.title}</h3>
              <p className="dashboard-card-value">{card.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="dashboard-welcome">
        <div className="card">
          <h2>Bem-vindo ao Sistema de Gestão!</h2>
          <p>
            Use o menu lateral para navegar entre os módulos do sistema.
            Você pode gerenciar beneficiárias, profissionais, atendimentos,
            voluntários, campanhas e doações.
          </p>
        </div>
      </div>
    </div>
  )
}
