import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '../services/api'
import { toast } from 'react-toastify'
import { FiPlus, FiClock, FiCheckCircle } from 'react-icons/fi'

export default function Chamados() {
  const [showModal, setShowModal] = useState(false)
  const [formData, setFormData] = useState({
    titulo: '',
    descricao: '',
    categoria: 'TECNICO',
    prioridade: 'MEDIA'
  })

  const queryClient = useQueryClient()

  const { data: chamados, isLoading } = useQuery({
    queryKey: ['chamados'],
    queryFn: () => api.get('/chamados').then(r => r.data)
  })

  const createMutation = useMutation({
    mutationFn: (data) => api.post('/chamados', data),
    onSuccess: () => {
      queryClient.invalidateQueries(['chamados'])
      toast.success('Chamado criado com sucesso!')
      resetForm()
    },
    onError: () => toast.error('Erro ao criar chamado')
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    createMutation.mutate(formData)
  }

  const resetForm = () => {
    setFormData({ titulo: '', descricao: '', categoria: 'TECNICO', prioridade: 'MEDIA' })
    setShowModal(false)
  }

  const getPrioridadeColor = (prioridade) => {
    const colors = {
      BAIXA: '#10B981',
      MEDIA: '#F59E0B',
      ALTA: '#EF4444',
      URGENTE: '#DC2626'
    }
    return colors[prioridade] || '#6B7280'
  }

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Help Desk / Chamados</h1>
          <p>Sistema de suporte e gerenciamento de chamados</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <FiPlus size={20} />
          Novo Chamado
        </button>
      </div>

      <div className="dashboard-grid">
        {chamados?.map((c) => (
          <div key={c.id} className="card" style={{ borderLeft: `4px solid ${getPrioridadeColor(c.prioridade)}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3 style={{ color: 'var(--primary-purple)', marginBottom: '0.5rem' }}>
                #{c.id} - {c.titulo}
              </h3>
              <span className={`badge badge-${c.status.toLowerCase()}`}>
                {c.status}
              </span>
            </div>

            <p style={{ color: 'var(--gray)', marginBottom: '1rem' }}>
              {c.descricao}
            </p>

            <div style={{ display: 'flex', gap: '1rem', fontSize: '0.875rem', color: 'var(--gray)' }}>
              <div>
                <strong>Categoria:</strong> {c.categoria}
              </div>
              <div>
                <strong>Prioridade:</strong> {c.prioridade}
              </div>
            </div>

            {c.nomeCriadoPor && (
              <div style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: 'var(--gray)' }}>
                <strong>Criado por:</strong> {c.nomeCriadoPor}
              </div>
            )}

            {c.nomeAtribuidoPara && (
              <div style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: 'var(--gray)' }}>
                <strong>Atribuído para:</strong> {c.nomeAtribuidoPara}
              </div>
            )}
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={resetForm}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Novo Chamado</h2>
              <button className="modal-close" onClick={resetForm}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-group">
                <label>Título *</label>
                <input
                  className="input"
                  value={formData.titulo}
                  onChange={(e) => setFormData({...formData, titulo: e.target.value})}
                  required
                />
              </div>

              <div className="form-group">
                <label>Descrição *</label>
                <textarea
                  className="input"
                  rows="4"
                  value={formData.descricao}
                  onChange={(e) => setFormData({...formData, descricao: e.target.value})}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Categoria</label>
                  <select
                    className="input"
                    value={formData.categoria}
                    onChange={(e) => setFormData({...formData, categoria: e.target.value})}
                  >
                    <option value="TECNICO">Técnico</option>
                    <option value="ADMINISTRATIVO">Administrativo</option>
                    <option value="ATENDIMENTO">Atendimento</option>
                    <option value="OUTRO">Outro</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Prioridade</label>
                  <select
                    className="input"
                    value={formData.prioridade}
                    onChange={(e) => setFormData({...formData, prioridade: e.target.value})}
                  >
                    <option value="BAIXA">Baixa</option>
                    <option value="MEDIA">Média</option>
                    <option value="ALTA">Alta</option>
                    <option value="URGENTE">Urgente</option>
                  </select>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={resetForm}>
                  Cancelar
                </button>
                <button type="submit" className="btn btn-primary">
                  Criar Chamado
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
