import { useQuery } from '@tanstack/react-query'
import api from '../services/api'

export default function Doacoes() {
  const { data: doacoes, isLoading } = useQuery({
    queryKey: ['doacoes'],
    queryFn: () => api.get('/doacoes').then(r => r.data)
  })

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Doações</h1>
          <p>Histórico de doações recebidas</p>
        </div>
      </div>

      <div className="table-container card">
        <table className="table">
          <thead>
            <tr>
              <th>Doador</th>
              <th>Email</th>
              <th>Valor</th>
              <th>Data</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {doacoes?.map((d) => (
              <tr key={d.id}>
                <td>{d.nomeDoador || 'Anônimo'}</td>
                <td>{d.emailDoador || '-'}</td>
                <td>R$ {d.valorDoacao?.toLocaleString('pt-BR')}</td>
                <td>{d.dataDoacao ? new Date(d.dataDoacao).toLocaleDateString('pt-BR') : '-'}</td>
                <td>
                  <span className={`badge badge-${d.status.toLowerCase()}`}>
                    {d.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
