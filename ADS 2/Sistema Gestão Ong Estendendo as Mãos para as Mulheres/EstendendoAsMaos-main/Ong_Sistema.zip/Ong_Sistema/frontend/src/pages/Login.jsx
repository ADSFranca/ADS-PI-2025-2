import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { toast } from 'react-toastify'
import { FiMail, FiLock } from 'react-icons/fi'
import './Login.css'

export default function Login() {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

const handleSubmit = async (e) => {
  e.preventDefault()
  console.log('handleSubmit clicado com', email, senha)
  setLoading(true)

  try {
    const data = await login(email, senha)
    console.log('Login OK, dados recebidos:', data)
    toast.success('Login realizado com sucesso!')
    navigate('/admin')
  } catch (error) {
    console.log('Erro capturado no handleSubmit:', error)
    toast.error('Email ou senha inválidos')
  } finally {
    setLoading(false)
  }
}

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <h1>Sistema ONG</h1>
            <p>Entre para gerenciar o sistema</p>
          </div>

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="email">
                <FiMail size={18} />
                Email
              </label>
              <input
                id="email"
                type="email"
                className="input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="senha">
                <FiLock size={18} />
                Senha
              </label>
              <input
                id="senha"
                type="password"
                className="input"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>

          <div className="login-footer">
            <p>Credenciais padrão: admin@ong.org / admin123</p>
          </div>
        </div>
      </div>
    </div>
  )
}
