import { useQuery } from '@tanstack/react-query'
import api from '../services/api'

export default function Voluntarios() {
  const { data: voluntarios, isLoading } = useQuery({
    queryKey: ['voluntarios'],
    queryFn: () => api.get('/voluntarios').then(r => r.data)
  })

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Voluntários</h1>
          <p>Gerencie os voluntários da ONG</p>
        </div>
      </div>

      <div className="table-container card">
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Email</th>
              <th>Área de Interesse</th>
              <th>Horas Trabalhadas</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {voluntarios?.map((v) => (
              <tr key={v.id}>
                <td>{v.nomeCompleto}</td>
                <td>{v.email}</td>
                <td>{v.areaInteresse || '-'}</td>
                <td>{v.horasTrabalhadas}h</td>
                <td>
                  <span className={`badge badge-${v.status.toLowerCase()}`}>
                    {v.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
