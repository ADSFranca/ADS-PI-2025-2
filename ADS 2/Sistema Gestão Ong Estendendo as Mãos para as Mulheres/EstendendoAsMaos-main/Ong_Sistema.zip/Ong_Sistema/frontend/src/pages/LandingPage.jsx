import { Link } from 'react-router-dom'
import { FiHeart, FiUsers, FiTarget, FiArrowRight } from 'react-icons/fi'
import './LandingPage.css'

export default function LandingPage() {
  return (
    <div className="landing">
      <header className="landing-header">
        <div className="container">
          <h1>ONG Sistema</h1>
          <Link to="/login" className="btn btn-primary">
            Acessar Sistema
            <FiArrowRight />
          </Link>
        </div>
      </header>

      <section className="hero">
        <div className="container">
          <h2>Transformando Vidas Através do Cuidado</h2>
          <p>
            Apoiamos mulheres em situação de vulnerabilidade oferecendo
            atendimento psicológico, jurídico e assistência social.
          </p>
          <div className="hero-actions">
            <button className="btn btn-primary">
              <FiHeart />
              Seja Voluntário
            </button>
            <button className="btn btn-secondary">
              Fazer Doação
            </button>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2>Como Ajudamos</h2>
          <div className="features-grid">
            <div className="feature-card card">
              <div className="feature-icon">
                <FiUsers size={32} />
              </div>
              <h3>Atendimento Especializado</h3>
              <p>Psicólogos, advogados e assistentes sociais dedicados</p>
            </div>

            <div className="feature-card card">
              <div className="feature-icon">
                <FiHeart size={32} />
              </div>
              <h3>Acolhimento Humanizado</h3>
              <p>Ambiente seguro e acolhedor para todas as beneficiárias</p>
            </div>

            <div className="feature-card card">
              <div className="feature-icon">
                <FiTarget size={32} />
              </div>
              <h3>Projetos e Campanhas</h3>
              <p>Campanhas contínuas para arrecadação e conscientização</p>
            </div>
          </div>
        </div>
      </section>

      <footer className="landing-footer">
        <div className="container">
          <p>© 2025 ONG Sistema. Transformando vidas com amor e dedicação.</p>
        </div>
      </footer>
    </div>
  )
}
