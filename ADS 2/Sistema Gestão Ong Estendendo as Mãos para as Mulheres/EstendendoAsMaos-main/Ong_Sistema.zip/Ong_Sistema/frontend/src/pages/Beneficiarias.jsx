import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '../services/api'
import { toast } from 'react-toastify'
import { FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi'
import './Beneficiarias.css'

export default function Beneficiarias() {
  const [showModal, setShowModal] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [formData, setFormData] = useState({
    nomeCompleto: '',
    cpf: '',
    dataNascimento: '',
    endereco: '',
    telefone: '',
    email: ''
  })

  const queryClient = useQueryClient()

  const { data: beneficiarias, isLoading } = useQuery({
    queryKey: ['beneficiarias'],
    queryFn: () => api.get('/beneficiarias').then(r => r.data)
  })

  const createMutation = useMutation({
    mutationFn: (data) => api.post('/beneficiarias', data),
    onSuccess: () => {
      queryClient.invalidateQueries(['beneficiarias'])
      toast.success('Beneficiária cadastrada com sucesso!')
      resetForm()
    },
    onError: () => toast.error('Erro ao cadastrar beneficiária')
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => api.put(`/beneficiarias/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['beneficiarias'])
      toast.success('Beneficiária atualizada com sucesso!')
      resetForm()
    },
    onError: () => toast.error('Erro ao atualizar beneficiária')
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (editingId) {
      updateMutation.mutate({ id: editingId, data: formData })
    } else {
      createMutation.mutate(formData)
    }
  }

  const handleEdit = (beneficiaria) => {
    setEditingId(beneficiaria.id)
    setFormData({
      nomeCompleto: beneficiaria.nomeCompleto,
      cpf: beneficiaria.cpf || '',
      dataNascimento: beneficiaria.dataNascimento || '',
      endereco: beneficiaria.endereco || '',
      telefone: beneficiaria.telefone || '',
      email: beneficiaria.email || ''
    })
    setShowModal(true)
  }

  const resetForm = () => {
    setFormData({
      nomeCompleto: '',
      cpf: '',
      dataNascimento: '',
      endereco: '',
      telefone: '',
      email: ''
    })
    setEditingId(null)
    setShowModal(false)
  }

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Beneficiárias</h1>
          <p>Gerencie as beneficiárias cadastradas</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <FiPlus size={20} />
          Nova Beneficiária
        </button>
      </div>

      <div className="table-container card">
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Telefone</th>
              <th>Email</th>
              <th>Data Cadastro</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {beneficiarias?.map((b) => (
              <tr key={b.id}>
                <td>{b.nomeCompleto}</td>
                <td>{b.telefone || '-'}</td>
                <td>{b.email || '-'}</td>
                <td>{b.dataCadastro ? new Date(b.dataCadastro).toLocaleDateString('pt-BR') : '-'}</td>
                <td>
                  <div className="table-actions">
                    <button className="btn-icon" onClick={() => handleEdit(b)}>
                      <FiEdit2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={resetForm}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingId ? 'Editar' : 'Nova'} Beneficiária</h2>
              <button className="modal-close" onClick={resetForm}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-group">
                <label>Nome Completo *</label>
                <input
                  className="input"
                  value={formData.nomeCompleto}
                  onChange={(e) => setFormData({...formData, nomeCompleto: e.target.value})}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>CPF *</label>
                  <input
                    className="input"
                    value={formData.cpf}
                    onChange={(e) => setFormData({...formData, cpf: e.target.value})}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Data Nascimento</label>
                  <input
                    type="date"
                    className="input"
                    value={formData.dataNascimento}
                    onChange={(e) => setFormData({...formData, dataNascimento: e.target.value})}
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Endereço</label>
                <input
                  className="input"
                  value={formData.endereco}
                  onChange={(e) => setFormData({...formData, endereco: e.target.value})}
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Telefone</label>
                  <input
                    className="input"
                    value={formData.telefone}
                    onChange={(e) => setFormData({...formData, telefone: e.target.value})}
                  />
                </div>

                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    className="input"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={resetForm}>
                  Cancelar
                </button>
                <button type="submit" className="btn btn-primary">
                  {editingId ? 'Atualizar' : 'Cadastrar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
