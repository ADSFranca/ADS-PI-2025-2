import { useQuery } from '@tanstack/react-query'
import api from '../services/api'

export default function Profissionais() {
  const { data: profissionais, isLoading } = useQuery({
    queryKey: ['profissionais'],
    queryFn: () => api.get('/profissionais').then(r => r.data)
  })

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Profissionais</h1>
          <p>Gerencie os profissionais cadastrados</p>
        </div>
      </div>

      <div className="table-container card">
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Tipo</th>
              <th>Email</th>
              <th>Telefone</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {profissionais?.map((p) => (
              <tr key={p.id}>
                <td>{p.nomeCompleto}</td>
                <td>{p.tipo}</td>
                <td>{p.email}</td>
                <td>{p.telefone || '-'}</td>
                <td>
                  <span className={`badge badge-${p.status.toLowerCase()}`}>
                    {p.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
