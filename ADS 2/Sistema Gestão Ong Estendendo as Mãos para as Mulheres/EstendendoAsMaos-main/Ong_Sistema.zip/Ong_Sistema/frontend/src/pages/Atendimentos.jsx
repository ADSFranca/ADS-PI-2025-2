import { useQuery } from '@tanstack/react-query'
import api from '../services/api'

export default function Atendimentos() {
  const { data: atendimentos, isLoading } = useQuery({
    queryKey: ['atendimentos'],
    queryFn: () => api.get('/atendimentos').then(r => r.data)
  })

  if (isLoading) return <div>Carregando...</div>

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Atendimentos</h1>
          <p>Histórico de atendimentos realizados</p>
        </div>
      </div>

      <div className="table-container card">
        <table className="table">
          <thead>
            <tr>
              <th>Beneficiária</th>
              <th>Profissional</th>
              <th>Tipo</th>
              <th>Data/Hora</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {atendimentos?.map((a) => (
              <tr key={a.id}>
                <td>{a.nomeBeneficiaria}</td>
                <td>{a.nomeProfissional}</td>
                <td>{a.tipoAtendimento}</td>
                <td>{new Date(a.dataHoraAtendimento).toLocaleString('pt-BR')}</td>
                <td>
                  <span className={`badge badge-${a.status.toLowerCase()}`}>
                    {a.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
