import { useQuery } from '@tanstack/react-query'
import api from '../services/api'
import { Line, Bar, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import './Relatorios.css'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
)

export default function Relatorios() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['relatorio-estatisticas'],
    queryFn: () => api.get('/relatorios/estatisticas').then(r => r.data)
  })

  if (isLoading) return <div>Carregando estatísticas...</div>

  // Dados para gráfico de atendimentos por tipo
  const atendimentosData = {
    labels: Object.keys(stats?.atendimentosPorTipo || {}),
    datasets: [{
      label: 'Atendimentos por Tipo',
      data: Object.values(stats?.atendimentosPorTipo || {}),
      backgroundColor: [
        'rgba(124, 58, 237, 0.8)',
        'rgba(249, 115, 22, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(245, 158, 11, 0.8)',
        'rgba(239, 68, 68, 0.8)',
        'rgba(99, 102, 241, 0.8)'
      ]
    }]
  }

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Relatórios e Estatísticas</h1>
          <p>Análise completa dos dados do sistema</p>
        </div>
      </div>

      <div className="relatorio-stats-grid">
        <div className="stat-card">
          <h3>Beneficiárias</h3>
          <p className="stat-number">{stats?.totalBeneficiarias || 0}</p>
          <span className="stat-label">Ativas: {stats?.beneficiariasAtivas || 0}</span>
        </div>

        <div className="stat-card">
          <h3>Profissionais</h3>
          <p className="stat-number">{stats?.totalProfissionais || 0}</p>
          <span className="stat-label">Ativos: {stats?.profissionaisAtivos || 0}</span>
        </div>

        <div className="stat-card">
          <h3>Voluntários</h3>
          <p className="stat-number">{stats?.totalVoluntarios || 0}</p>
          <span className="stat-label">{stats?.horasTotaisVoluntariado || 0}h trabalhadas</span>
        </div>

        <div className="stat-card">
          <h3>Atendimentos</h3>
          <p className="stat-number">{stats?.totalAtendimentos || 0}</p>
          <span className="stat-label">Realizados: {stats?.atendimentosRealizados || 0}</span>
        </div>

        <div className="stat-card">
          <h3>Doações</h3>
          <p className="stat-number">R$ {(stats?.totalDoacoes || 0).toLocaleString('pt-BR')}</p>
          <span className="stat-label">Total arrecadado</span>
        </div>

        <div className="stat-card">
          <h3>Chamados</h3>
          <p className="stat-number">{stats?.chamadosAbertos || 0}</p>
          <span className="stat-label">Abertos / {stats?.chamadosResolvidos || 0} Resolvidos</span>
        </div>
      </div>

      <div className="charts-grid">
        <div className="chart-container card">
          <h3>Atendimentos por Tipo</h3>
          <div style={{ height: '300px' }}>
            <Bar data={atendimentosData} options={chartOptions} />
          </div>
        </div>

        <div className="chart-container card">
          <h3>Distribuição de Atendimentos</h3>
          <div style={{ height: '300px' }}>
            <Doughnut data={atendimentosData} options={chartOptions} />
          </div>
        </div>
      </div>

      {stats?.itensEstoqueBaixo > 0 && (
        <div className="card" style={{ backgroundColor: '#FEF3C7', padding: '1.5rem', marginTop: '2rem' }}>
          <h3 style={{ color: '#92400E' }}>⚠️ Atenção!</h3>
          <p style={{ color: '#92400E' }}>
            Há <strong>{stats.itensEstoqueBaixo}</strong> itens com estoque abaixo do mínimo.
          </p>
        </div>
      )}
    </div>
  )
}
