import { useState } from 'react'
import api from '../services/api'

export const useAuth = () => {
  const [token, setToken] = useState(localStorage.getItem('token'))
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem('user') || 'null')
  )

  const login = async (email, senha) => {
  try {
    console.log('login() chamado com', email, senha)
    const response = await api.post('/auth/login', { email, senha })
    console.log('resposta da API', response)

    const { token, id, email: userEmail, nome } = response.data

    localStorage.setItem('token', token)
    localStorage.setItem('user', JSON.stringify({ id, email: userEmail, nome }))

    setToken(token)
    setUser({ id, email: userEmail, nome })

    return response.data
  } catch (error) {
    console.error('Erro no login() - detalhes:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data,
    })
    throw error
  }
}


  const logout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setToken(null)
    setUser(null)
  }

  return { token, user, login, logout }
}
