import { NavLink } from 'react-router-dom'
import { FiHome, FiUsers, FiHeart, FiCalendar, FiUserPlus, FiTarget, FiDollarSign, FiMessageSquare, FiBarChart2 } from 'react-icons/fi'
import './Sidebar.css'

export default function Sidebar() {
  const menuItems = [
    { path: '/admin', icon: FiHome, label: 'Dashboard', exact: true },
    { path: '/admin/beneficiarias', icon: FiUsers, label: 'Beneficiárias' },
    { path: '/admin/profissionais', icon: FiUserPlus, label: 'Profissionais' },
    { path: '/admin/atendimentos', icon: FiCalendar, label: 'Atendimentos' },
    { path: '/admin/voluntarios', icon: FiHeart, label: 'Voluntários' },
    { path: '/admin/campanhas', icon: FiTarget, label: 'Campanhas' },
    { path: '/admin/doacoes', icon: FiDollarSign, label: 'Doações' },
    { path: '/admin/chamados', icon: FiMessageSquare, label: 'Help Desk' },
    { path: '/admin/relatorios', icon: FiBarChart2, label: 'Relatórios' },
  ]

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h2>ONG Sistema</h2>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.exact}
            className={({ isActive }) => 
              `sidebar-link ${isActive ? 'sidebar-link-active' : ''}`
            }
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
