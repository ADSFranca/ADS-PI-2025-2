import { useAuth } from '../hooks/useAuth'
import { FiLogOut, FiUser } from 'react-icons/fi'
import './Header.css'

export default function Header() {
  const { user, logout } = useAuth()

  return (
    <header className="header">
      <div className="header-content">
        <h1 className="header-title">Sistema de Gestão</h1>

        <div className="header-user">
          <div className="header-user-info">
            <FiUser size={20} />
            <span>{user?.nome || user?.email || 'Usuário'}</span>
          </div>

          <button onClick={logout} className="header-logout">
            <FiLogOut size={20} />
            Sair
          </button>
        </div>
      </div>
    </header>
  )
}
