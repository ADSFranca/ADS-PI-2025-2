import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'

// Pages
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Beneficiarias from './pages/Beneficiarias'
import Profissionais from './pages/Profissionais'
import Atendimentos from './pages/Atendimentos'
import Voluntarios from './pages/Voluntarios'
import Campanhas from './pages/Campanhas'
import Doacoes from './pages/Doacoes'
import Chamados from './pages/Chamados'
import Relatorios from './pages/Relatorios'
import LandingPage from './pages/LandingPage'

// Layout
import Layout from './components/Layout'

function App() {
  const { token } = useAuth()

  return (
    <Routes>
      {/* Rotas Públicas */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<Login />} />

      {/* Rotas Privadas */}
      {token ? (
        <Route path="/admin" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="beneficiarias" element={<Beneficiarias />} />
          <Route path="profissionais" element={<Profissionais />} />
          <Route path="atendimentos" element={<Atendimentos />} />
          <Route path="voluntarios" element={<Voluntarios />} />
          <Route path="campanhas" element={<Campanhas />} />
          <Route path="doacoes" element={<Doacoes />} />
          <Route path="chamados" element={<Chamados />} />
          <Route path="relatorios" element={<Relatorios />} />
        </Route>
      ) : (
        <Route path="/admin/*" element={<Navigate to="/login" replace />} />
      )}
    </Routes>
  )
}

export default App
