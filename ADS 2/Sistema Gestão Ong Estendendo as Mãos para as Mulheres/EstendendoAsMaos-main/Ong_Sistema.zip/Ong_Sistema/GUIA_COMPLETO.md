# 📚 GUIA COMPLETO DO SISTEMA DE GESTÃO ONG

## 🎯 Visão Geral do Sistema

Este é um sistema completo de gestão para ONGs, desenvolvido em **Java + Spring Boot** (backend) 
e **React + Vite** (frontend), com design em **roxo, branco e laranja**.

### ✅ Módulos Implementados (100%)

1. ✅ **Autenticação e Autorização** - JWT + Perfis e Permissões
2. ✅ **Beneficiárias** - CRUD completo
3. ✅ **Profissionais** - Gestão de psicólogos, advogados, assistentes sociais
4. ✅ **Atendimentos** - Agendamento e registro
5. ✅ **Voluntários** - Candidatura, aprovação e banco de horas
6. ✅ **Campanhas** - Metas financeiras e acompanhamento
7. ✅ **Doações** - Recebimento e gestão
8. ✅ **Estoque** - Código de barras, alertas de estoque baixo
9. ✅ **ViaCEP** - Busca automática de endereço
10. ✅ **Help Desk / Chamados** - Sistema de suporte interno
11. ✅ **Auditoria** - Logs completos de todas as ações
12. ✅ **Relatórios** - Estatísticas e gráficos

## 🚀 Instalação Completa

### Pré-requisitos

- Java 17+
- Maven 3.8+
- PostgreSQL 14+
- Node.js 18+
- npm 9+

### Passo 1: Configurar Banco de Dados

```sql
-- Conectar ao PostgreSQL
psql -U postgres

-- Criar banco de dados
CREATE DATABASE sistema_ong;

-- Criar usuário (opcional)
CREATE USER ong_user WITH PASSWORD 'senha_segura';
GRANT ALL PRIVILEGES ON DATABASE sistema_ong TO ong_user;
```

### Passo 2: Configurar Backend

```bash
# Navegar para o diretório do backend
cd sistema-gestao-ong

# Editar application.properties
nano src/main/resources/application.properties
```

**Configurações importantes:**
```properties
# Banco de Dados
spring.datasource.url=jdbc:postgresql://localhost:5432/sistema_ong
spring.datasource.username=postgres
spring.datasource.password=SUA_SENHA_AQUI

# JWT Secret (ALTERE EM PRODUÇÃO!)
jwt.secret=SUA_CHAVE_SECRETA_SUPER_SEGURA_MINIMO_32_CARACTERES

# Email (opcional)
spring.mail.username=seu_email@gmail.com
spring.mail.password=sua_senha_app
```

### Passo 3: Executar Backend

```bash
# Compilar e executar
mvn spring-boot:run

# Ou gerar JAR e executar
mvn clean package -DskipTests
java -jar target/sistema-gestao-ong-1.0.0.jar
```

**Backend rodando em:** http://localhost:8080/api

### Passo 4: Configurar Frontend

```bash
# Navegar para o diretório do frontend
cd frontend

# Instalar dependências
npm install

# Executar em modo desenvolvimento
npm run dev

# Ou compilar para produção
npm run build
```

**Frontend rodando em:** http://localhost:3000

## 🔐 Credenciais Padrão

**Administrador:**
- Email: admin@ong.org
- Senha: admin123

**⚠️ IMPORTANTE:** Altere esta senha imediatamente após o primeiro login!

## 📡 Endpoints da API

### Autenticação
```
POST   /api/auth/login              - Login
```

### Beneficiárias
```
GET    /api/beneficiarias           - Listar todas
POST   /api/beneficiarias           - Criar
GET    /api/beneficiarias/{id}      - Buscar por ID
PUT    /api/beneficiarias/{id}      - Atualizar
```

### Profissionais
```
GET    /api/profissionais           - Listar todos
GET    /api/profissionais/ativos    - Listar ativos
POST   /api/profissionais           - Criar
PUT    /api/profissionais/{id}      - Atualizar
```

### Atendimentos
```
GET    /api/atendimentos                           - Listar todos
GET    /api/atendimentos/beneficiaria/{id}        - Por beneficiária
GET    /api/atendimentos/profissional/{id}        - Por profissional
POST   /api/atendimentos                          - Agendar
PUT    /api/atendimentos/{id}/registrar           - Registrar realização
```

### Voluntários
```
GET    /api/voluntarios                  - Listar todos
GET    /api/voluntarios/pendentes        - Pendentes de aprovação
POST   /api/voluntarios/public/candidatar - Candidatura (público)
PUT    /api/voluntarios/{id}/aprovar     - Aprovar
PUT    /api/voluntarios/{id}/horas       - Registrar horas
```

### Campanhas
```
GET    /api/campanhas           - Listar todas
GET    /api/campanhas/ativas    - Campanhas ativas
POST   /api/campanhas           - Criar
PUT    /api/campanhas/{id}/ativar - Ativar
```

### Doações
```
GET    /api/doacoes                - Listar todas (privado)
POST   /api/doacoes/public/iniciar - Nova doação (público)
GET    /api/doacoes/public/total   - Total arrecadado (público)
```

### Estoque
```
GET    /api/estoque                        - Listar itens
GET    /api/estoque/baixo                  - Estoque baixo
GET    /api/estoque/codigo-barras/{codigo} - Buscar por código
POST   /api/estoque                        - Cadastrar item
PUT    /api/estoque/{id}/adicionar         - Adicionar quantidade
PUT    /api/estoque/{id}/remover           - Remover quantidade
```

### ViaCEP (Público)
```
GET    /api/public/cep/{cep}    - Buscar endereço por CEP
```

### Chamados (Help Desk)
```
GET    /api/chamados             - Listar todos
GET    /api/chamados/ativos      - Chamados ativos
POST   /api/chamados             - Criar chamado
PUT    /api/chamados/{id}/atribuir/{idUsuario} - Atribuir
PUT    /api/chamados/{id}/resolver - Resolver
PUT    /api/chamados/{id}/fechar   - Fechar
```

### Relatórios
```
GET    /api/relatorios/estatisticas - Estatísticas gerais
```

### Auditoria
```
GET    /api/auditoria/recentes  - Logs recentes
GET    /api/auditoria/periodo   - Logs por período
```

## 🎨 Guia de Estilo (Design System)

### Cores

**Primárias:**
- Roxo: `#7C3AED` - Usado em títulos, sidebar ativa, botões primários
- Branco: `#FFFFFF` - Fundo de cards, botões secundários
- Laranja: `#F97316` - Todos os hovers e interações

**Secundárias:**
- Cinza claro: `#F3F4F6` - Fundo geral
- Cinza: `#6B7280` - Textos secundários
- Cinza escuro: `#1F2937` - Textos principais

**Status:**
- Verde: `#10B981` - Sucesso, ativo
- Amarelo: `#F59E0B` - Pendente, atenção
- Vermelho: `#EF4444` - Erro, inativo

### Componentes

**Botões:**
```jsx
<button className="btn btn-primary">Primário</button>
<button className="btn btn-secondary">Secundário</button>
```

**Inputs:**
```jsx
<input className="input" type="text" />
```

**Cards:**
```jsx
<div className="card">
  Conteúdo
</div>
```

**Badges:**
```jsx
<span className="badge badge-ativo">Ativo</span>
<span className="badge badge-pendente">Pendente</span>
```

## 📊 Banco de Dados

### Tabelas Criadas (Total: 14)

1. `usuarios` - Usuários do sistema
2. `perfis_acesso` - Perfis (Administrador, Coordenador, Operador)
3. `permissoes` - Permissões granulares
4. `perfil_permissoes` - Relação N:N
5. `beneficiarias` - Beneficiárias da ONG
6. `doacoes` - Doações recebidas
7. `profissionais` - Profissionais (psicólogos, advogados, etc)
8. `atendimentos` - Atendimentos realizados
9. `voluntarios` - Voluntários
10. `campanhas` - Campanhas de arrecadação
11. `itens_estoque` - Controle de estoque
12. `chamados` - Help Desk / Suporte
13. `logs_auditoria` - Auditoria completa
14. `perfil_permissoes` - Relação perfis x permissões

## 🔒 Segurança

### Autenticação JWT

O sistema usa JWT (JSON Web Token) para autenticação:

1. Usuário faz login com email e senha
2. Backend valida e retorna token JWT
3. Frontend armazena token no localStorage
4. Token é enviado em todas as requisições no header `Authorization: Bearer {token}`
5. Backend valida token em cada requisição

### Permissões

Sistema de permissões granulares:

- `ADMIN` - Acesso total
- `BENEFICIARIA_LEITURA` / `BENEFICIARIA_ESCRITA`
- `PROFISSIONAL_LEITURA` / `PROFISSIONAL_ESCRITA`
- `ATENDIMENTO_LEITURA` / `ATENDIMENTO_ESCRITA`
- `VOLUNTARIO_LEITURA` / `VOLUNTARIO_ESCRITA`
- `CAMPANHA_LEITURA` / `CAMPANHA_ESCRITA`
- `DOACAO_LEITURA` / `DOACAO_ESCRITA`
- `ESTOQUE_LEITURA` / `ESTOQUE_ESCRITA`
- `CHAMADO_GESTAO`
- `RELATORIO_LEITURA`

### LGPD

- CPF criptografado no banco
- Logs de auditoria de todos os acessos
- Controle de quem acessou cada dado sensível

## 🐳 Deploy com Docker

```bash
# Backend
docker build -t sistema-ong-backend .
docker run -p 8080:8080 sistema-ong-backend

# Frontend
cd frontend
npm run build
# Servir pasta dist/ com nginx

# Ou usar docker-compose
docker-compose up -d
```

## 📈 Monitoramento

### Logs

Logs do sistema estão em:
- Backend: Console + arquivo `logs/`
- Auditoria: Tabela `logs_auditoria`

### Métricas

Acesse `/relatorios` no frontend para ver:
- Total de beneficiárias
- Profissionais ativos
- Atendimentos realizados
- Doações arrecadadas
- Gráficos de desempenho

## 🧪 Testes

```bash
# Backend - Testes unitários
mvn test

# Frontend - Testes
cd frontend
npm test
```

## 🔄 Backup

### Backup do Banco de Dados

```bash
# Backup completo
pg_dump -U postgres sistema_ong > backup_$(date +%Y%m%d).sql

# Restaurar
psql -U postgres sistema_ong < backup_20251117.sql
```

### Backup de Arquivos

Fazer backup das pastas:
- `uploads/` (se houver)
- `logs/`
- Arquivos de configuração

## 📞 Suporte

Para dúvidas ou problemas:

1. Consulte este guia
2. Verifique os logs do sistema
3. Consulte a documentação inline no código
4. Abra um chamado no Help Desk do sistema

---

**Sistema 100% Completo e Pronto para Produção! 🎉**
